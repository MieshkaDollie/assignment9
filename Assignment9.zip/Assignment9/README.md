Name: Jesmaias Constantino Paulino
Surname: David
Group: 3G

Problem Domain:
E-commerce of Books

Problem Specification:
Nowadays people are very busy so they don’t have much time to go to a physical store that’s when an online store becomes very convenient. People can order books online using a payment method choice of whichever they deem fit(Card, Paypal).
    
