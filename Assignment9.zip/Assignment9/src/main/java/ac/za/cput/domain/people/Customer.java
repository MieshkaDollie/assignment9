package ac.za.cput.domain.people;

import ac.za.cput.domain.admin.*;

import java.util.Set;

public class Customer {

    private String id, firstName, lastName, email,phoneNumber;
    private int age;
    private Set<Book> book;
    private Set<Order> order;
    private Set<Review>review;
    private Set<Comment>comment;
    private Set<Card> card;
    private Set<Address> address;

    private Customer(){}

    private Customer(Builder builder) {
        this.id=builder.id;
        this.firstName = builder.firstName;
        this.age = builder.age;
        this.lastName = builder.lastName;
        this.email = builder.email;
        this.phoneNumber = builder.phoneNumber;
    }

    public String getId(){return id;}

    public String getFirstName() {
        return firstName;
    }


    public String getLastName() {
        return lastName;
    }

    public int getAge() {
        return age;
    }

    public String getEmail() {
        return email;

    }



    public String getPhoneNumber() {
        return phoneNumber;
    }


    public static class Builder {

        private String id, firstName, lastName, email,phoneNumber;
        private int age;
        private Set<Book> book;
        private Set<Order> order;
        private Set<Review>review;
        private Set<Comment>comment;
        private Set<Card> card;
        private Set<Address> address;
        private CustomerStatus cs;

        public Builder id(String id){
            this.id=id;
            return this;
        }

        public Builder firstName( String firstName) {
            this.firstName = firstName;
            return this;
        }

        public Builder  lastName( String  lastName) {
            this.lastName =  lastName;
            return this;
        }

        public Builder age( int age) {
            this.age= age;
            return this;
        }

        public Builder  email( String email) {
            this.email =  email;
            return this;
        }



        public Builder  phoneNumber( String phoneNumber) {
            this.phoneNumber= phoneNumber;
            return this;
        }

        public Customer build() {
            return new Customer(this);
        }

        public Builder copy(Customer customer) {
            this.age= customer.age;
            this.firstName= customer.firstName;
            this.email= customer.email;
            this.lastName= customer.lastName;
            this.phoneNumber= customer.phoneNumber;
            return this;
        }

    }

    @Override
    public String toString() {
        return "Customer{" +
                "FirstName='" + firstName + '\'' +
                ", userLastName'" + lastName + '\'' +
                ", userAge'" + age + '\'' +
                ",userEmail" + email + ",userPhoneNumber" + phoneNumber +
                '}';
    }


}
