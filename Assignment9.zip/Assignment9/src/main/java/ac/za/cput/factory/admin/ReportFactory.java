package ac.za.cput.factory.admin;

import ac.za.cput.domain.admin.Report;

public class ReportFactory {

    public static Report getReport(String reportID,String date, String description, double sale) {
        return new Report.Builder().reportID(reportID)
                .date(date)
                .description(description)
                .sale(sale)
                .build();
    }
}
