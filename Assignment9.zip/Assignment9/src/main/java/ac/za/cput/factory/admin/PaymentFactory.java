package ac.za.cput.factory.admin;

import ac.za.cput.domain.admin.Payment;

public class PaymentFactory {

    public static Payment getPayment(String id, double amount) {
        return new Payment.Builder().id(id)
                .amount(amount)
                .build();
    }
}
