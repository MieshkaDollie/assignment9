package ac.za.cput.controller.admin;

import ac.za.cput.domain.admin.GeneralBook;
import ac.za.cput.service.admin.GeneralBookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.*;

import java.util.Set;

@RestController
@RequestMapping("/generalBook")
public class GeneralBookController {
    @Autowired
    @Qualifier("ServiceImpl")
    private GeneralBookService service;

    @PostMapping("/create")
    @ResponseBody
    public GeneralBook create(GeneralBook generalBook) {
        return service.create(generalBook);
    }

    @PostMapping("/update")
    @ResponseBody
    public GeneralBook update(GeneralBook generalBook ) {
        return service.update(generalBook);
    }

    @GetMapping("/delete/{id}")
    @ResponseBody
    public void delete(@PathVariable String id) {
        service.delete(id);

    }

    @GetMapping("/read/{id}")
    @ResponseBody
    public GeneralBook read(@PathVariable String id) {
        return service.read(id);
    }

    @GetMapping("/read/all")
    @ResponseBody
    public Set<GeneralBook> getAll() {
        return service.getAll();
    }


}
