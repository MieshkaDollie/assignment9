package ac.za.cput.controller.admin;


import ac.za.cput.domain.admin.Comment;
import ac.za.cput.service.admin.CommentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.*;

import java.util.Set;

@RestController
@RequestMapping("/comment")
public class CommentController {


    @Autowired
    @Qualifier("ServiceImpl")
    private CommentService service;

    @PostMapping("/create")
    @ResponseBody
    public Comment create(Comment comment) {
        return service.create(comment);
    }

    @PostMapping("/update")
    @ResponseBody
    public Comment update(Comment comment) {
        return service.update(comment);
    }

    @GetMapping("/delete/{id}")
    @ResponseBody
    public void delete(@PathVariable String id) {
        service.delete(id);

    }

    @GetMapping("/read/{id}")
    @ResponseBody
    public Comment read(@PathVariable String id) {
        return service.read(id);
    }

    @GetMapping("/read/all")
    @ResponseBody
    public Set<Comment> getAll() {
        return service.getAll();
    }
}
