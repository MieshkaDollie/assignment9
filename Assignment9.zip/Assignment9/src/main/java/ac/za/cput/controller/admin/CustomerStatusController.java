package ac.za.cput.controller.admin;

import ac.za.cput.domain.admin.CustomerStatus;
import ac.za.cput.service.admin.CustomerStatusService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.*;

import java.util.Set;

@RestController
@RequestMapping("/customerStatus")
public class CustomerStatusController {

    @Autowired
    @Qualifier("ServiceImpl")
    private CustomerStatusService service;

    @PostMapping("/create")
    @ResponseBody
    public CustomerStatus create(CustomerStatus customerStatus) {
        return service.create(customerStatus);
    }

    @PostMapping("/update")
    @ResponseBody
    public CustomerStatus update(CustomerStatus customerStatus) {
        return service.update(customerStatus);
    }

    @GetMapping("/delete/{id}")
    @ResponseBody
    public void delete(@PathVariable String id) {
        service.delete(id);

    }

    @GetMapping("/read/{id}")
    @ResponseBody
    public CustomerStatus read(@PathVariable String id) {
        return service.read(id);
    }

    @GetMapping("/read/all")
    @ResponseBody
    public Set<CustomerStatus> getAll() {
        return service.getAll();
    }
}
