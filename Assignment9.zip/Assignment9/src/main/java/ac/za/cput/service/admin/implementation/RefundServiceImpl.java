package ac.za.cput.service.admin.implementation;

import ac.za.cput.domain.admin.Refund;
import ac.za.cput.repository.admin.RefundRepository;
import ac.za.cput.repository.admin.implementation.RefundRepositoryImpl;
import ac.za.cput.service.admin.RefundService;

import java.util.Set;

public class RefundServiceImpl implements RefundService {

    private static RefundServiceImpl service = null;
    private RefundRepository repository;

    private RefundServiceImpl() {
        this.repository = RefundRepositoryImpl.getRepository();
    }

    public static RefundServiceImpl getService(){
        if (service == null) service = new RefundServiceImpl();
        return service;
    }



    @Override
    public Set<Refund> getAll() {
        return this.repository.getAll();
    }

    @Override
    public Refund create(Refund refund) {
        return this.repository.create(refund);
    }

    @Override
    public Refund update(Refund refund) {
        return this.repository.update(refund);
    }

    @Override
    public void delete(String s) {
    this.repository.delete(s);
    }

    @Override
    public Refund read(String s) {
        return this.repository.read(s);
    }
}
