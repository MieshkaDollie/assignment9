package ac.za.cput.repository.people.implementation;

import ac.za.cput.domain.people.Author;
import ac.za.cput.repository.people.AuthorRepository;

import java.util.HashSet;
import java.util.Set;

public class AuthorRepositoryImpl implements AuthorRepository {


    private static AuthorRepositoryImpl repository = null;
    private Set<Author> authors;

    private AuthorRepositoryImpl (){
        this.authors = new HashSet<>();
    }

    private Author findAuthor(final String authorBio) {
        return this.authors.stream()
                .filter(author ->author.getBio().trim().equals(authorBio))
                .findAny()
                .orElse(null);
    }

    public static AuthorRepositoryImpl getRepository() {
        if (repository == null) repository = new AuthorRepositoryImpl();
        return repository;
    }

    @Override
    public Set<Author> getAll() {
        return  authors;
    }

    @Override
    public Author create(Author author) {
        this.authors.add(author);
        return author;
    }

    @Override
    public Author update(Author author) {
        Author toDelete = findAuthor(author.getBio());
        if(toDelete != null) {
            this.authors.remove(toDelete);
            return create(author);
        }
        return null;
    }

    @Override
    public void delete(String s) {
        Author author= findAuthor(s);
        if (author != null) this.authors.remove(author);
    }

    @Override
    public Author read(String s) {
        Author author= findAuthor(s);
        return author;
    }
}
