package ac.za.cput.service.people;

import ac.za.cput.domain.people.Customer;
import ac.za.cput.service.IService;

import java.util.Set;

public interface CustomerService extends IService<Customer,String> {
    Set<Customer> getAll();
}

