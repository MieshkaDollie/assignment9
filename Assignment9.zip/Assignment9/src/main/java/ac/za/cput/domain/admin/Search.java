package ac.za.cput.domain.admin;

public class Search {

    private String bookName;

    private Search(){}

    private Search(Builder builder){
        this.bookName=builder.bookName;
    }

    public String bookName(){return bookName;}

    public static class Builder{
         private String bookName;

         public Builder bookName(String bookName){
             this.bookName=bookName;
             return this;
         }

         public Search build(){return new Search();}

        public Builder copy(Search search) {
            this.bookName=search.bookName;
            return this;
        }
    }

    @Override
    public String toString() {
        return "Report{" +
                "book name='" + bookName+ '\'' +
                '}';
    }

}
