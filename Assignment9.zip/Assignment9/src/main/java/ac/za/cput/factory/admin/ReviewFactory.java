package ac.za.cput.factory.admin;

import ac.za.cput.domain.admin.Review;

public class ReviewFactory {

    public static Review getReview(String reviewId, String customerId, String content) {
        return new Review.Builder().reviewId(reviewId)
                .customerId(customerId)
                .content(content)
                .build();
    }
}
