package ac.za.cput.factory.admin;

import ac.za.cput.domain.admin.Book;

public class BookFactory {

    public static Book getBook(String id, String title, String author, String category, String edition, String edDate, String description) {
        return new Book.Builder().id(id)
                .title(title)
                .author(author)
                .category(category)
                .edition(edition)
                .editionDate(edDate)
                .description(description)
                .build();
    }
}
