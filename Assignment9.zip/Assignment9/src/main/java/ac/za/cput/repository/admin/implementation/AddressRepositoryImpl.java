package ac.za.cput.repository.admin.implementation;

import ac.za.cput.domain.admin.Account;
import ac.za.cput.domain.admin.Address;
import ac.za.cput.repository.admin.AddressRepository;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class AddressRepositoryImpl implements AddressRepository {


    private static AddressRepositoryImpl repository = null;
    private List<Address> address;

    private AddressRepositoryImpl (){
        this.address = new ArrayList<>();
    }

    private Address findAddress(final String type) {
        return this.address.stream()
                .filter(address -> address.getType().trim().equals(type))
                .findAny()
                .orElse(null);
    }

    public static AddressRepositoryImpl getRepository(){
        if (repository == null) repository = new AddressRepositoryImpl();
        return repository;
    }

    @Override
    public List<Address> getAll() {
        return address;
    }

    @Override
    public Address create(Address address) {
        this.address.add(address);


        return address;
    }

    @Override
    public Address update(Address address) {

        Address toDelete = findAddress(address.getType());
        if(toDelete != null) {
            this.address.remove(toDelete);
            return create(address);
        }
        return null;
    }

    @Override
    public void delete(String s) {

        Address address = findAddress(s);
        if (address != null) this.address.remove(address);
    }

    @Override
    public Address read(String s) {
        Address address=findAddress(s);
        return address ;
}
}
