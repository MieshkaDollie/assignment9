package ac.za.cput.controller.admin;

import ac.za.cput.domain.admin.Invoice;
import ac.za.cput.service.admin.InvoiceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.*;

import java.util.Set;

@RestController
@RequestMapping("/invoice")
public class InvoiceController {

    @Autowired
    @Qualifier("ServiceImpl")
    private InvoiceService service;

    @PostMapping("/create")
    @ResponseBody
    public Invoice create(Invoice invoice) {
        return service.create(invoice);
    }

    @PostMapping("/update")
    @ResponseBody
    public Invoice update(Invoice invoice ) {
        return service.update(invoice);
    }

    @GetMapping("/delete/{id}")
    @ResponseBody
    public void delete(@PathVariable String id) {
        service.delete(id);

    }

    @GetMapping("/read/{id}")
    @ResponseBody
    public Invoice read(@PathVariable String id) {
        return service.read(id);
    }

    @GetMapping("/read/all")
    @ResponseBody
    public Set<Invoice> getAll() {
        return service.getAll();
    }


}
