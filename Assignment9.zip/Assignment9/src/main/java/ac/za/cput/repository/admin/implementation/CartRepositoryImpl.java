package ac.za.cput.repository.admin.implementation;

import ac.za.cput.domain.admin.Cart;
import ac.za.cput.domain.admin.Coupon;
import ac.za.cput.repository.admin.CartRepository;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class CartRepositoryImpl implements CartRepository {



    private static CartRepositoryImpl repository = null;
    private Set<Cart> cart;

    private CartRepositoryImpl (){
        this.cart = new HashSet<>();
    }

    private Cart findCart(final String cartID) {
        return this.cart.stream()
                .filter(cart ->cart.getId().trim().equals(cartID))
                .findAny()
                .orElse(null);
    }

    public static CartRepositoryImpl getRepository(){
        if (repository == null) repository = new CartRepositoryImpl();
        return repository;
    }


    @Override
    public Set<Cart> getAll() {
        return cart;
    }

    @Override
    public Cart create(Cart cart) {
        this.cart.add(cart);

        return cart;
    }

    @Override
    public Cart update(Cart cart) {
        Cart toDelete = findCart(cart.getBookId());
        if(toDelete != null) {
            this.cart.remove(toDelete);
            return create(cart);
        }
        return null;
    }

    @Override
    public void delete(String s) {

       Cart cart= findCart(s);
        if (cart != null) this.cart.remove(cart);

    }

    @Override
    public Cart read(String s) {
       Cart cart=findCart(s);
        return cart;
    }
}
