package ac.za.cput.service.admin.implementation;

import ac.za.cput.domain.admin.Comment;
import ac.za.cput.repository.admin.CommentRepository;
import ac.za.cput.repository.admin.implementation.CommentRepositoryImpl;
import ac.za.cput.service.admin.CommentService;

import java.util.Set;

public class CommentServiceImpl implements CommentService {

    private static CommentServiceImpl service = null;
    private CommentRepository repository;

    private CommentServiceImpl() {
        this.repository = CommentRepositoryImpl.getRepository();
    }

    public static CommentServiceImpl getService(){
        if (service == null) service = new CommentServiceImpl();
        return service;
    }



    @Override
    public Set<Comment> getAll() {
        return this.repository.getAll();
    }

    @Override
    public Comment create(Comment comment) {
        return this.repository.create(comment);
    }

    @Override
    public Comment update(Comment comment) {
        return this.repository.update(comment);
    }

    @Override
    public void delete(String s) {
       this.repository.delete(s);
    }

    @Override
    public Comment read(String s) {
        return this.repository.read(s);
    }
}
