package ac.za.cput.factory.admin;

import ac.za.cput.domain.admin.OrderStatus;

public class OrderStatusFactory {

    public static OrderStatus getOrderStatus(String o, String ci) {
        return new OrderStatus.Builder().customerId(ci)
                .orderNumber(o)
                .build();
    }
}
