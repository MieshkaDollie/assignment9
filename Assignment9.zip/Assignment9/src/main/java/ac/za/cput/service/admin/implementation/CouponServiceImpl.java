package ac.za.cput.service.admin.implementation;

import ac.za.cput.domain.admin.Coupon;
import ac.za.cput.repository.admin.CouponRepository;
import ac.za.cput.repository.admin.implementation.CouponRepositoryImpl;
import ac.za.cput.service.admin.CouponService;

import java.util.Set;

public class CouponServiceImpl implements CouponService {

    private static CouponServiceImpl service = null;
    private CouponRepository repository;

    private CouponServiceImpl() {
        this.repository = CouponRepositoryImpl.getRepository();
    }

    public static CouponServiceImpl getService(){
        if (service == null) service = new CouponServiceImpl();
        return service;
    }



    @Override
    public Set<Coupon> getAll() {
        return this.repository.getAll();
    }

    @Override
    public Coupon create(Coupon coupon) {
        return this.repository.create(coupon);
    }

    @Override
    public Coupon update(Coupon coupon) {
        return this.repository.update(coupon);
    }

    @Override
    public void delete(String s) {
         this.repository.delete(s);
    }

    @Override
    public Coupon read(String s) {
        return this.read(s);
    }
}
