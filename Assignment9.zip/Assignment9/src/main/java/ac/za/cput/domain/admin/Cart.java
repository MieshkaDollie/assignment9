package ac.za.cput.domain.admin;

public class Cart {

    private String id,bookId,category;
    private int amount;

    private Cart(){}

    private Cart(Builder builder) {
        this.id=builder.id;
        this.bookId=builder.bookId;
        this.amount = builder.amount;
        this.category= builder.category;

    }
    public String getId(){return id;}

    public String getBookId() {
        return bookId;
    }

    public int getAmount() {
        return amount;
    }

    public String getCategory() {
        return category;
    }

    public static class Builder {

        private String id,bookId,category;
        private int amount;

        public Builder id(String id){
            this.id=id;
            return this;
        }

        public Builder bookId(String bookId) {
            this.bookId = bookId;
            return this;
        }

        public Builder category(String category) {
            this.category = category;
            return this;
        }

        public Builder amount(int amount) {
            this.amount = amount;
            return this;
        }

        public Cart build() {
            return new Cart(this);
        }

        public Builder copy(Cart cart) {
            this.id=cart.id;
            this.amount=cart.amount;
            this.bookId=cart.bookId;
            this.category=cart.category;
            return this;
        }
    }


    @Override
    public String toString() {
        return "CartFactory{" +
                "id='" + id +
                "book id='" + bookId+ '\'' +
                ",amount ='" +amount + '\'' +
                ",category ='" + category+ '\'' +
                '}';
    }


}