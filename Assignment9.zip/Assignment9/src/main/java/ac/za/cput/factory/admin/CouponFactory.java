package ac.za.cput.factory.admin;

import ac.za.cput.domain.admin.Coupon;

public class CouponFactory {


    public static Coupon getCoupon(String couponId, String dateEff, String dateLoseEff) {
        return new Coupon.Builder().couponId(couponId)
                .dateEff(dateEff)
                .dateLoseEff(dateLoseEff)
                .build();
    }
}
