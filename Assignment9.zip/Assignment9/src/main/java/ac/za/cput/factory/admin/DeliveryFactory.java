package ac.za.cput.factory.admin;

import ac.za.cput.domain.admin.Delivery;

public class DeliveryFactory {


    public static Delivery getDelivery(String  code, String date) {
        return new Delivery.Builder().code(code)
                .date(date)
                .build();
    }
}
