package ac.za.cput.repository.admin;

import ac.za.cput.domain.admin.ReferenceBook;
import ac.za.cput.repository.IRepository;

import java.util.Set;

public interface ReferenceBookRepository extends IRepository<ReferenceBook,String> {
    Set<ReferenceBook> getAll();
}
