package ac.za.cput.domain.admin;

public class Address {

    private String type,street,road,city,country;

    private Address(){}

    private Address(Builder builder) {
        this.type=builder.type;
        this.street = builder.street;
        this.road= builder.road;
        this.city= builder.city;
        this.country= builder.country;
    }

    public String getType() {
        return type;
    }

    public String getStreet() {
        return street;
    }

    public String getRoad() {
        return road;
    }

    public String getCity() {
        return city;
    }

    public String getCountry() {
        return country;
    }

    public static class Builder {

        private String type, street, road, city, country;

        public Builder type(String type) {
            this.type = type;
            return this;
        }

        public Builder street(String street) {
            this.street = street;
            return this;
        }

        public Builder road(String road) {
            this.road = road;
            return this;
        }

        public Builder city(String city) {
            this.city = city;
            return this;
        }

        public Builder country(String country) {
            this.country = country;
            return this;
        }

        public Address build() {
            return new Address(this);
        }

        public Builder copy(Address address) {
            this.type=address.type;
            this.city=address.city;
            this.country=address.country;
            this.road=address.road;
            this.street=address.street;


            return this;
        }
    }

    @Override
    public String toString() {
        return "Address{" +
                "type='" + type + '\'' +
                ",street ='" + street + '\'' +
                ",road ='" + road+ '\'' +
                ",city ='" + city+ '\''+
                ",country ='" + country+ '\''+
                '}';
    }
}
