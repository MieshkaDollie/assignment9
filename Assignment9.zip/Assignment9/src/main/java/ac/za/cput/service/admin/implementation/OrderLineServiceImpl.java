package ac.za.cput.service.admin.implementation;

import ac.za.cput.domain.admin.OrderLine;
import ac.za.cput.service.admin.OrderLineService;

import java.util.Set;

public class OrderLineServiceImpl implements OrderLineService {

    /*private static OrderLineServiceImpl service = null;
    private OrderLine repository;

    private CardServiceImpl() {
        this.repository = OrderLineRepositoryImpl.getRepository();
    }

    public static CardServiceImpl getService(){
        if (service == null) service = new CardServiceImpl();
        return service;
    }*/


    @Override
    public Set<OrderLine> getAll() {
        return null;
    }

    @Override
    public OrderLine create(OrderLine orderLine) {
        return null;
    }

    @Override
    public OrderLine update(OrderLine orderLine) {
        return null;
    }

    @Override
    public void delete(String s) {

    }

    @Override
    public OrderLine read(String s) {
        return null;
    }
}
