package ac.za.cput.repository.admin;

import ac.za.cput.domain.admin.Order;
import ac.za.cput.repository.IRepository;

import java.util.Set;

public interface OrderRepository extends IRepository<Order,String> {

    Set<Order> getAll();
}
