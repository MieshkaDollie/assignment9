package ac.za.cput.service.admin;

import ac.za.cput.domain.admin.Review;
import ac.za.cput.service.IService;

import java.util.Set;

public interface ReviewService extends IService<Review,String> {
    Set<Review> getAll();
}

