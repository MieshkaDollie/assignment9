package ac.za.cput.repository.people;

import ac.za.cput.domain.people.Author;
import ac.za.cput.repository.IRepository;

import java.util.Set;

public interface AuthorRepository extends IRepository<Author,String> {

    Set<Author> getAll();
}
