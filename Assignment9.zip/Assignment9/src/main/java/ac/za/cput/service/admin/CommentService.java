package ac.za.cput.service.admin;

import ac.za.cput.domain.admin.Comment;
import ac.za.cput.service.IService;

import java.util.Set;

public interface CommentService extends IService<Comment,String> {
    Set<Comment> getAll();
}
