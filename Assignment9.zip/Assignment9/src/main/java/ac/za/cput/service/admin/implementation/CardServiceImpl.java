package ac.za.cput.service.admin.implementation;

import ac.za.cput.domain.admin.Card;
import ac.za.cput.repository.admin.CardRepository;
import ac.za.cput.repository.admin.implementation.CardRepositoryImpl;
import ac.za.cput.service.admin.CardService;

import java.util.Set;

public class CardServiceImpl implements CardService {

    private static CardServiceImpl service = null;
    private CardRepository repository;

    private CardServiceImpl() {
        this.repository = CardRepositoryImpl.getRepository();
    }

    public static CardServiceImpl getService(){
        if (service == null) service = new CardServiceImpl();
        return service;
    }

    @Override
    public Set<Card> getAll() {
        return this.repository.getAll();
    }

    @Override
    public Card create(Card card) {
        return this.repository.create(card);
    }

    @Override
    public Card update(Card card) {
        return this.repository.update(card);
    }

    @Override
    public void delete(String s) {
              this.repository.delete(s);
    }

    @Override
    public Card read(String s) {
        return this.repository.read(s);
    }
}
