package ac.za.cput.factory.admin;

import ac.za.cput.domain.admin.OrderLine;

public class OrderLineFactory {



        public static OrderLine getOrderLine(String orderNum,String bookid, double amount, String description) {
        return new OrderLine.Builder().orderNum(orderNum)
                .bookID(bookid)
                .amount(amount)
                .description(description)
                .build();
    }
}
