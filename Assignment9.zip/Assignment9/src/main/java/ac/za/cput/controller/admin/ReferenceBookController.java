package ac.za.cput.controller.admin;

import ac.za.cput.domain.admin.ReferenceBook;
import ac.za.cput.service.admin.ReferenceBookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.*;

import java.util.Set;

@RestController
@RequestMapping("/referenceBook")
public class ReferenceBookController {

    @Autowired
    @Qualifier("ServiceImpl")
    private ReferenceBookService service;

    @PostMapping("/create")
    @ResponseBody
    public ReferenceBook create(ReferenceBook referenceBook) {
        return service.create(referenceBook);
    }

    @PostMapping("/update")
    @ResponseBody
    public ReferenceBook update(ReferenceBook referenceBook) {
        return service.update(referenceBook);
    }

    @GetMapping("/delete/{id}")
    @ResponseBody
    public void delete(@PathVariable String id) {
        service.delete(id);

    }

    @GetMapping("/read/{id}")
    @ResponseBody
    public ReferenceBook read(@PathVariable String id) {
        return service.read(id);
    }

    @GetMapping("/read/all")
    @ResponseBody
    public Set<ReferenceBook> getAll() {
        return service.getAll();
    }
}
