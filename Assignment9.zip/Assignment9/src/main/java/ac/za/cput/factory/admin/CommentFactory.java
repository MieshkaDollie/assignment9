package ac.za.cput.factory.admin;

import ac.za.cput.domain.admin.Comment;

public class CommentFactory {



    public static Comment getComment(String commentId,String bookId, String customerId) {
        return new Comment.Builder().commentId(commentId)
                .customerId(customerId)
                .bookId(bookId)
                .build();
    }
}
