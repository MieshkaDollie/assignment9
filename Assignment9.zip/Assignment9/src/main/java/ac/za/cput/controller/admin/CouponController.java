package ac.za.cput.controller.admin;

import ac.za.cput.domain.admin.Coupon;
import ac.za.cput.service.admin.CouponService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.*;

import java.util.Set;

@RestController
@RequestMapping("/coupon")
public class CouponController {


    @Autowired
    @Qualifier("ServiceImpl")
    private CouponService service;

    @PostMapping("/create")
    @ResponseBody
    public Coupon create(Coupon coupon) {
        return service.create(coupon);
    }

    @PostMapping("/update")
    @ResponseBody
    public Coupon update(Coupon coupon) {
        return service.update(coupon);
    }

    @GetMapping("/delete/{id}")
    @ResponseBody
    public void delete(@PathVariable String id) {
        service.delete(id);

    }

    @GetMapping("/read/{id}")
    @ResponseBody
    public Coupon read(@PathVariable String id) {
        return service.read(id);
    }

    @GetMapping("/read/all")
    @ResponseBody
    public Set<Coupon> getAll() {
        return service.getAll();
    }
}
