package ac.za.cput.repository.admin;

import ac.za.cput.repository.IRepository;

import java.util.Set;

public interface OrderLine extends IRepository<OrderLine,String> {

    Set<OrderLine> getAll();
}
