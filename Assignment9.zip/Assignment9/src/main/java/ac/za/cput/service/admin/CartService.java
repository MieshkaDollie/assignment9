package ac.za.cput.service.admin;

import ac.za.cput.domain.admin.Cart;
import ac.za.cput.service.IService;

import java.util.Set;

public interface CartService extends IService<Cart,String> {
    Set<Cart> getAll();
}