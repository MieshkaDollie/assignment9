package ac.za.cput.domain.admin;

import java.util.Set;

public class Book {

    private String bookId, bookTitle, bookAuthor, bookCategory,bookEdition,bookDescription;
    private String bookEdDate;
    private Set<Review>review;
    private Set<Comment> comment;


    private Book(){}
    private Book(Builder builder) {
        this.bookId=builder.bookId;
        this.bookTitle = builder.bookTitle;
        this.bookAuthor = builder.bookAuthor;
        this.bookCategory = builder.bookCategory;
        this.bookEdition = builder.bookEdition;
        this.bookEdDate = builder.bookEdDate;
        this.bookDescription = builder.bookDescription;
    }

    public String getBookId(){ return bookId;}

    public String getTitle(){
        return bookTitle;
    }

    public String getAuthor(){
        return bookAuthor;
    }

    public String getCategory(){
        return bookCategory;
    }

    public String getEdition(){
        return bookEdition;
    }

    public String getEditionDate(){
        return bookEdDate;
    }

    public String getDescription(){
        return bookDescription;
    }


    public static class Builder {

        private String bookId, bookTitle, bookAuthor, bookCategory,bookEdition,bookDescription;
        private String bookEdDate;

        public Builder id(String bookId){
            this.bookId=bookId;
            return  this;
        }

        public Builder title( String bookTitle) {
            this.bookTitle = bookTitle;
            return this;
        }

        public Builder  author( String  bookAuthor) {
            this.bookAuthor =  bookAuthor;
            return this;
        }

        public Builder category( String bookCategory) {
            this.bookCategory= bookCategory;
            return this;
        }

        public Builder  edition( String bookEdition) {
            this.bookEdition =  bookEdition;
            return this;
        }

        public Builder  editionDate( String bookEdDate) {
            this.bookEdDate = bookEdDate;
            return this;
        }

        public Builder  description( String bookDescription) {
            this.bookDescription= bookDescription;
            return this;
        }


        public Book build() {
            return new Book(this);
        }


        public Builder copy(Book book) {
            this.bookId=book.bookId;
            this.bookTitle = book.bookTitle;
            this.bookAuthor =  book.bookAuthor;
            this.bookCategory= book.bookCategory;
            this.bookEdition =  book.bookEdition;
            this.bookEdDate = book.bookEdDate;
            this.bookDescription= book.bookDescription;

            return this;
        }
    }

    @Override
    public String toString() {
        return "Book{" +
                "title='" + bookTitle + '\'' +
                ", author='" + bookAuthor + '\'' +
                ", category='" + bookCategory + '\'' +
                ", edition='" + bookEdition + "', edition date=" + bookEdDate +
                '}';
    }




}
