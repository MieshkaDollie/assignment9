package ac.za.cput.service.admin;

import ac.za.cput.domain.admin.Publisher;
import ac.za.cput.service.IService;

import java.util.Set;

public interface PublisherService extends IService<Publisher,String> {
    Set<Publisher> getAll();
}

