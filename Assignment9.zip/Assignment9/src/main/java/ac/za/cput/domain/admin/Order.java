package ac.za.cput.domain.admin;

import java.util.ArrayList;

public class Order {

    private String orderNumber;
    private String custId;
    private double amount;
    private String description;
    private ArrayList<OrderLine> orderLine;
    private OrderStatus os;


    private Order(Builder builder) {
        this.orderNumber = builder.orderNumber;
        this.custId = builder.customerId;
        this.amount = builder.amount;
        this.description = builder.description;

    }

    public String getOrderNumber() {
        return orderNumber;
    }

    public String getCustomerId() {
        return custId;
    }

    public double getAmount() {
        return amount;
    }

    public String getDescription() {
        return description;
    }

    public static class Builder {

        private String orderNumber;
        private String customerId;
        private double amount;
        private String description;

        public Builder orderNumber(String orderNumber) {
            this.orderNumber = orderNumber;
            return this;
        }

        public Builder customerId(String customerId) {
            this.customerId = customerId;
            return this;
        }

        public Builder amount(double amount) {
            this.amount = amount;
            return this;
        }

        public Builder description(String description) {
            this.description = description;
            return this;
        }

        public Order build() {
            return new Order(this);
        }

        public Builder copy(Order order) {
            this.orderNumber=order.orderNumber;
            this.amount=order.amount;
            this.description=order.description;
            this.customerId=order.custId;
            return this;
        }

    }

    @Override
    public String toString() {
        return "Order{" +
                "order number='" + orderNumber + '\'' +
                ", customer id'" + custId + '\'' +
                ", amount'" + amount + '\'' +
                ",description" + description +
                '}';
    }
}
