package ac.za.cput.factory.admin;

import ac.za.cput.domain.admin.Search;

public class SearchFactory {

    public static Search getSearch(String bookname) {
        return new Search.Builder().bookName(bookname)
                .build();
    }
}
