package ac.za.cput.repository.admin.implementation;

import ac.za.cput.domain.admin.Search;
import ac.za.cput.repository.admin.SearchRepository;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

public class SearchRepositoryImpl implements SearchRepository {

    private static SearchRepositoryImpl repository = null;
    private List<Search> searches;

    private SearchRepositoryImpl (){
        this.searches = new ArrayList<>();
    }

    private Search findSearch(final String bookName) {
        return this.searches.stream()
                .filter(search ->search.bookName().trim().equals(bookName))
                .findAny()
                .orElse(null);
    }

    public static SearchRepositoryImpl getRepository() {
        if (repository == null) repository = new SearchRepositoryImpl();
        return repository;
    }

    @Override
    public List<Search> getAll() {
        return searches;
    }

    @Override
    public Search create(Search search) {
        this.searches.add(search);
        return search;
    }

    @Override
    public Search update(Search search) {
        Search toDelete = findSearch(search.bookName());
        if(toDelete != null) {
            this.searches.remove(toDelete);
            return create(search);
        }
        return null;
    }

    @Override
    public void delete(String s) {
        Search search= findSearch(s);
        if (search != null) this.searches.remove(search);
    }

    @Override
    public Search read(String s) {
        Search search= findSearch(s);
        return search;
    }
}
