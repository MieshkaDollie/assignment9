package ac.za.cput.service.admin.implementation;

import ac.za.cput.domain.admin.ReferenceBook;
import ac.za.cput.repository.admin.ReferenceBookRepository;
import ac.za.cput.repository.admin.implementation.ReferenceBookRepositoryImpl;
import ac.za.cput.service.admin.ReferenceBookService;

import java.util.Set;

public class ReferenceBookServiceImpl implements ReferenceBookService {

    private static ReferenceBookServiceImpl service = null;
    private ReferenceBookRepository repository;

    private ReferenceBookServiceImpl() {
        this.repository = ReferenceBookRepositoryImpl.getRepository();
    }

    public static ReferenceBookServiceImpl getService(){
        if (service == null) service = new ReferenceBookServiceImpl();
        return service;
    }


    @Override
    public Set<ReferenceBook> getAll() {
        return this.repository.getAll();
    }

    @Override
    public ReferenceBook create(ReferenceBook referenceBook) {
        return this.repository.create(referenceBook);
    }

    @Override
    public ReferenceBook update(ReferenceBook referenceBook) {
        return this.repository.update(referenceBook);
    }

    @Override
    public void delete(String s) {
      this.repository.delete(s);
    }

    @Override
    public ReferenceBook read(String s) {
        return this.repository.read(s);
    }
}
