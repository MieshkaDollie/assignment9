package ac.za.cput.controller.admin;

import ac.za.cput.domain.admin.Card;
import ac.za.cput.service.admin.CardService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.*;

import java.util.Set;

@RestController
@RequestMapping("/card")
public class CardController {

    @Autowired
    @Qualifier("ServiceImpl")
    private CardService service;

    @PostMapping("/create")
    @ResponseBody
    public Card create(Card card) {
        return service.create(card);
    }

    @PostMapping("/update")
    @ResponseBody
    public Card update(Card card) {
        return service.update(card);
    }

    @GetMapping("/delete/{id}")
    @ResponseBody
    public void delete(@PathVariable String id) {
        service.delete(id);

    }

    @GetMapping("/read/{id}")
    @ResponseBody
    public Card read(@PathVariable String id) {
        return service.read(id);
    }

    @GetMapping("/read/all")
    @ResponseBody
    public Set<Card> getAll() {
        return service.getAll();
    }


}
