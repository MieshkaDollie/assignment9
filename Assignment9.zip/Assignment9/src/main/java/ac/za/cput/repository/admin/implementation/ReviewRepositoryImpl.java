package ac.za.cput.repository.admin.implementation;

import ac.za.cput.domain.admin.Review;
import ac.za.cput.repository.admin.ReviewRepository;

import java.util.HashSet;
import java.util.Set;

public class ReviewRepositoryImpl implements ReviewRepository {

    private static ReviewRepositoryImpl repository = null;
    private Set<Review> reviews;

    private ReviewRepositoryImpl (){
        this.reviews = new HashSet<>();
    }

    private Review findReview(final String reviewID) {
        return this.reviews.stream()
                .filter(review ->review.getReviewId().trim().equals(reviewID))
                .findAny()
                .orElse(null);
    }

    public static ReviewRepositoryImpl getRepository() {
        if (repository == null) repository = new ReviewRepositoryImpl();
        return repository;
    }

    @Override
    public Set<Review> getAll() {
        return reviews;
    }

    @Override
    public Review create(Review review) {
        this.reviews.add(review);
        return review;
    }

    @Override
    public Review update(Review review) {
        Review toDelete = findReview(review.getReviewId());
        if(toDelete != null) {
            this.reviews.remove(toDelete);
            return create(review);
        }
        return null;
    }

    @Override
    public void delete(String s) {
        Review review= findReview(s);
        if (review != null) this.reviews.remove(review);
    }

    @Override
    public Review read(String s) {
        Review review= findReview(s);
        return review;
    }
}
