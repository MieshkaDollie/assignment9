package ac.za.cput.repository.admin;

import ac.za.cput.domain.admin.Comment;
import ac.za.cput.repository.IRepository;

import java.util.Set;

public interface CommentRepository extends IRepository<Comment,String> {
    Set<Comment> getAll();
}
