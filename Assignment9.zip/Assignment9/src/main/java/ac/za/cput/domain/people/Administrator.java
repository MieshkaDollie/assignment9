package ac.za.cput.domain.people;

public class Administrator {

    private String id,fname,sname;

    private Administrator(){}

    private Administrator(Builder builder) {
        this.id=builder.id;
        this.fname = builder.fname;
        this.sname= builder.sname;
    }

    public String getID() {
        return id;
    }

    public String getFName() {
        return fname;
    }

    public String getSName() {
        return sname;
    }


    public static class Builder {

        private String id,fname,sname;

        public Builder id(String id) {
            this.id = id;
            return this;
        }

        public Builder fName(String fname) {
            this.fname = fname;
            return this;
        }

        public Builder sName(String sname) {
            this.sname = sname;
            return this;
        }

        public Administrator build() {
            return new Administrator(this);
        }

        public Builder copy(Administrator administrator) {
            this.id=administrator.id;
            this.fname= administrator.fname;
            this.sname= administrator.sname;
            return this;
        }
    }

    @Override
    public String toString() {
        return "Administrator{" +
                "id='" + id + '\'' +
                ",first name ='" + fname + '\'' +
                ",surname ='" + sname+ '\'' +
                '}';
    }
}
