package ac.za.cput.repository.admin;

import ac.za.cput.domain.admin.Publisher;
import ac.za.cput.repository.IRepository;

import java.util.Set;

public interface PublisherRepository extends IRepository<Publisher,String> {
    Set<Publisher> getAll();
}
