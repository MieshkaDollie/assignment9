package ac.za.cput.service.admin;

import ac.za.cput.domain.admin.Search;
import ac.za.cput.service.IService;

import java.util.Set;

public interface SearchService extends IService<Search,String> {
    Set<Search> getAll();
}

