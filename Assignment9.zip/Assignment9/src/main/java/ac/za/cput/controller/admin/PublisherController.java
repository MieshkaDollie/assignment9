package ac.za.cput.controller.admin;

import ac.za.cput.domain.admin.Publisher;
import ac.za.cput.service.admin.PublisherService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.*;

import java.util.Set;

@RestController
@RequestMapping("/publisher")
public class PublisherController {

    @Autowired
    @Qualifier("ServiceImpl")
    private PublisherService service;

    @PostMapping("/create")
    @ResponseBody
    public Publisher create(Publisher publisher) {
        return service.create(publisher);
    }

    @PostMapping("/update")
    @ResponseBody
    public Publisher update(Publisher publisher) {
        return service.update(publisher);
    }

    @GetMapping("/delete/{id}")
    @ResponseBody
    public void delete(@PathVariable String id) {
        service.delete(id);

    }

    @GetMapping("/read/{id}")
    @ResponseBody
    public Publisher read(@PathVariable String id) {
        return service.read(id);
    }

    @GetMapping("/read/all")
    @ResponseBody
    public Set<Publisher> getAll() {
        return service.getAll();
    }
}
