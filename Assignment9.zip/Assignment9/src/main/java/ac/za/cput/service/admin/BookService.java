package ac.za.cput.service.admin;

import ac.za.cput.domain.admin.Book;
import ac.za.cput.service.IService;

import java.util.Set;

public interface BookService extends IService<Book,String> {
    Set<Book> getAll();
}
