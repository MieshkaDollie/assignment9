package ac.za.cput.factory.people;

import ac.za.cput.domain.people.Author;

public class AuthorFactory {



    public static Author getAuthor( String fnsme, String lname, int age,String bio) {
        return new Author.Builder().firstName(fnsme)
                .lastName(lname)
                .age(age)
                .bio(bio)
                .build();
    }
}
