package ac.za.cput.service.admin.implementation;

import ac.za.cput.domain.admin.Book;
import ac.za.cput.repository.admin.BookRepository;
import ac.za.cput.repository.admin.implementation.BookRepositoryImplementation;
import ac.za.cput.service.admin.BookService;

import java.util.Set;

public class BookServiceImpl implements BookService {

    private static BookServiceImpl service = null;
    private BookRepository repository;

    private BookServiceImpl() {
        this.repository = BookRepositoryImplementation.getRepository();
    }

    public static BookServiceImpl getService(){
        if (service == null) service = new BookServiceImpl();
        return service;
    }

    @Override
    public Set<Book> getAll() {
        return this.repository.getAll();
    }

    @Override
    public Book create(Book book) {
        return this.repository.create(book);
    }

    @Override
    public Book update(Book book) {
        return this.repository.update(book);
    }

    @Override
    public void delete(String s) {
           this.repository.delete(s);
    }

    @Override
    public Book read(String s) {
        return this.repository.read(s);
    }
}
