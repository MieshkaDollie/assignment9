package ac.za.cput.repository.admin;

import ac.za.cput.domain.admin.Card;
import ac.za.cput.repository.IRepository;

import java.util.Set;

public interface CardRepository extends IRepository<Card,String> {
    Set<Card> getAll();
}
