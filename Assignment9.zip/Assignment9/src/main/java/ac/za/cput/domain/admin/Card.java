package ac.za.cput.domain.admin;

public class Card {

    private String cardOwner,bank;
    private String cardNumber;

    private Card(){

    }

    private Card(Builder builder) {
        this.cardNumber=builder.cardNumber;
        this.cardOwner = builder.cardOwner;
        this.bank= builder.bank;

    }

    public String getCardNumber(){return cardNumber;}

    public String getCardOwner() {
        return cardOwner;
    }


    public String getBank() {
        return bank;
    }

    public static class Builder {

        private String cardOwner,bank;
        private String cardNumber;

        public Builder  cardNumber(String cardNumber){
            this.cardNumber=cardNumber;
            return this;
        }

        public Builder cardOwner( String cardOwner) {
            this.cardOwner = cardOwner;
            return this;
        }

        public Builder  bank( String  bank) {
            this.bank =  bank;
            return this;
        }

        public Card build() {
            return new Card(this);
        }


        public Builder copy(Card card) {
            this.bank=card.bank;
            this.cardOwner=card.cardOwner;
            this.cardNumber=card.cardNumber;

            return this;
        }
    }

    @Override
    public String toString() {
        return "Card{" +
                "card number='" + cardNumber + '\'' +
                ",card Owner ='" + cardOwner + '\'' +
                ", bank ='" + bank + '\'' +
                '}';
    }

}
