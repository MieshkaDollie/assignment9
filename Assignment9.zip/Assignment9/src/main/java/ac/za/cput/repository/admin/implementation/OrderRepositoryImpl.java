package ac.za.cput.repository.admin.implementation;

import ac.za.cput.domain.admin.Order;
import ac.za.cput.repository.admin.OrderRepository;

import java.util.HashSet;
import java.util.Set;

public class OrderRepositoryImpl implements OrderRepository {


    private static  OrderRepositoryImpl repository = null;
    private Set<Order> orders;

    private OrderRepositoryImpl (){
        this.orders = new HashSet<>();
    }

    private Order findOrder(final String num) {

        return this.orders.stream()
                .filter(order -> order.getOrderNumber().trim().equals(num))
                .findAny()
                .orElse(null);
    }

    public static OrderRepositoryImpl getRepository() {
        if (repository == null) repository = new OrderRepositoryImpl();
        return repository;
    }


    @Override
    public Set<Order> getAll() {
        return orders;
    }

    @Override
    public Order create(Order order) {
        this.orders.add(order);
        return order;
    }

    @Override
    public Order update(Order order) {
        Order toDelete = findOrder(order.getOrderNumber());
        if(toDelete != null) {
            this.orders.remove(toDelete);
            return create(order);
        }
        return null;
    }

    @Override
    public void delete(String s) {
        Order order= findOrder(s);
        if (order != null) this.orders.remove(order);
    }

    @Override
    public Order read(String s) {
        Order order= findOrder(s);
        return order;
    }
}
