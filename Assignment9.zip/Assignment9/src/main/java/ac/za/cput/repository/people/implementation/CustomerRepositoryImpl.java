package ac.za.cput.repository.people.implementation;

import ac.za.cput.domain.people.Customer;
import ac.za.cput.repository.people.CustomerRepository;

import java.util.HashSet;
import java.util.Set;

public class CustomerRepositoryImpl  implements CustomerRepository {


    private static CustomerRepositoryImpl  repository = null;
    private Set<Customer> customers;

    private CustomerRepositoryImpl  (){
        this.customers = new HashSet<>();
    }

    private Customer findCustomer(final String custID) {
        return this.customers.stream()
                .filter(customer ->customer.getId().trim().equals(custID))
                .findAny()
                .orElse(null);
    }

    public static CustomerRepositoryImpl  getRepository() {
        if (repository == null) repository = new CustomerRepositoryImpl ();
        return repository;
    }

    @Override
    public Set<Customer> getAll() {
        return customers;
    }

    @Override
    public Customer create(Customer customer) {
        this.customers.add(customer);
        return customer;
    }

    @Override
    public Customer update(Customer customer) {
        Customer toDelete = findCustomer(customer.getId());
        if(toDelete != null) {
            this.customers.remove(toDelete);
            return create(customer);
        }
        return null;
    }

    @Override
    public void delete(String s) {
        Customer customer= findCustomer(s);
        if (customer != null) this.customers.remove(customer);
    }

    @Override
    public Customer read(String s) {
        Customer customer= findCustomer(s);
        return customer;
    }
}
