package ac.za.cput.repository.admin.implementation;

import ac.za.cput.domain.admin.Invoice;
import ac.za.cput.repository.admin.InvoiceRepository;

import java.util.HashSet;
import java.util.Set;

public class InvoiceRepositoryImpl implements InvoiceRepository {

    private static InvoiceRepositoryImpl repository = null;
    private Set<Invoice> invoices;

    private InvoiceRepositoryImpl (){
        this.invoices = new HashSet<>();
    }

    private Invoice findInvoice( final String num) {
        return this.invoices.stream()
                .filter(invoice ->invoice.getNumber().trim().equals(num))
                .findAny()
                .orElse(null);
    }

    public static InvoiceRepositoryImpl getRepository() {
        if (repository == null) repository = new InvoiceRepositoryImpl();
        return repository;
    }


    @Override
    public Set<Invoice> getAll() {
        return invoices;
    }

    @Override
    public Invoice create(Invoice invoice) {
        this.invoices.add(invoice);

        return invoice;
    }

    @Override
    public Invoice update(Invoice invoice) {
        Invoice toDelete = findInvoice(invoice.getNumber());
        if(toDelete != null) {
            this.invoices.remove(toDelete);
            return create(invoice);
        }
        return null;
    }

    @Override
    public void delete(String s) {
        Invoice invoice= findInvoice(s);
        if (invoice != null) this.invoices.remove(invoice);
    }

    @Override
    public Invoice read(String s) {
        Invoice invoice= findInvoice(s);
        return invoice;
    }
}
