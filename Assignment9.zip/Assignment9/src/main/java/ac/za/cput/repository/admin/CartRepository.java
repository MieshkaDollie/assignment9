package ac.za.cput.repository.admin;

import ac.za.cput.domain.admin.Cart;
import ac.za.cput.domain.admin.Coupon;
import ac.za.cput.repository.IRepository;

import java.util.Set;

public interface CartRepository extends IRepository<Cart,String> {
    Set<Cart> getAll();
}
