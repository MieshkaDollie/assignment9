package ac.za.cput.service.admin;

import ac.za.cput.domain.admin.Invoice;
import ac.za.cput.service.IService;

import java.util.Set;

public interface InvoiceService extends IService<Invoice,String> {
    Set<Invoice> getAll();
}

