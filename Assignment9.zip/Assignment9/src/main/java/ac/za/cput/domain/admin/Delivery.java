package ac.za.cput.domain.admin;

public class Delivery {

    private String code,date;

    private Delivery(){}

    private Delivery(Builder builder) {
        this.code=builder.code;
        this.date= builder.date;
    }


    public String getCode(){return code;}

    public String getDate() {
        return date;
    }

    public static class Builder {

        private String code,date;

        public Builder code( String code) {
            this.code = code;
            return this;
        }

        public Builder  date( String date) {
            this.date =  date;
            return this;
        }

        public Delivery build() {
            return new Delivery(this);
        }

        public Builder copy(Delivery delivery) {
            this.code=delivery.code;
            this.date=delivery.date;
            return this;
        }
    }

    @Override
    public String toString() {
        return "Delivery{" +
                "code='" + code + '\'' +
                ", date'" + date+ '\'' +
                '}';
    }
}
