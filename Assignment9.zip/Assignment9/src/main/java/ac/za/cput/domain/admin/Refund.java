package ac.za.cput.domain.admin;

public class Refund {

    private String id;
    private double amount;

    private Refund(){}

    private Refund(Builder builder){

        this.id = builder.id;
        this.amount = builder.amount;
    }

    public String id() { return id;
    }

    public double amount() { return amount;
    }

    public static class Builder {

        private String id;
        private double amount;


        public Builder id(String id) {
            this.id =id;
            return this;
        }

        public Builder amount(double amount) {
            this.amount = amount;
            return this;
        }
        public Refund build() {
            return new Refund(this);
        }

        public Builder copy(Refund refund) {
            this.id=refund.id;
            this.amount=refund.amount;
            return this;
        }
    }
    @Override
    public String toString() {
        return "Refund{" +
                "id='" + id + '\'' +
                ", amount='" + amount + '\'' +
                '}';
    }
}
