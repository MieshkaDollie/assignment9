package ac.za.cput.service.admin;

import ac.za.cput.domain.admin.OrderStatus;
import ac.za.cput.service.IService;

import java.util.Set;

public interface OrderStatusService extends IService<OrderStatus,String> {
    Set<OrderStatus> getAll();
}

