package ac.za.cput.factory.admin;

import ac.za.cput.domain.admin.GeneralBook;

public class GeneralBookFactory {

    public static GeneralBook getGeneralBook(String  id, String title) {
        return new GeneralBook.Builder().id(id)
                .title(title)
                .build();
    }
}
