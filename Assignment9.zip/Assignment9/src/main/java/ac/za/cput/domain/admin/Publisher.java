package ac.za.cput.domain.admin;

import java.util.Set;

public class Publisher {

    private String code,name;
    private Set<Book> book;

    private Publisher(){}

    private Publisher(Builder builder){

        this.code = builder.code;
        this.name = builder.name;

    }

    public String getCode() {
        return code;
    }

    public String getName() {
        return name;
    }

    public static class Builder {

        private String code,name;


        public Builder code(String code) {
            this.code =code;
            return this;
        }

        public Builder name(String name) {
            this.name = name;
            return this;
        }
        public Publisher build() {
            return new Publisher(this);
        }

        public Builder copy(Publisher publisher) {
            this.code=publisher.code;
            this.name=publisher.name;
            return this;
        }
    }

    @Override
    public String toString() {
        return "Publisher{" +
                "code='" + code + '\'' +
                ", name='" + name + '\'' +
                '}';
    }
}
