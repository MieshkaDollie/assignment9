package ac.za.cput.domain.admin;

public class Comment {

    private String commentId, bookId,customerId;

    private Comment(){}

    private Comment(Builder builder) {
        this.commentId=builder.commentId;
        this.bookId = builder.bookId;
        this.customerId= builder.customerId;

    }

    public String getcommentId(){return commentId;}

    public String getbookId() {
        return bookId;
    }


    public String getcustomerId() {
        return customerId;
    }


    public static class Builder {

        private String commentId, bookId,customerId;

        public Builder commentId(String id){
            this.commentId=id;
            return this;
        }

        public Builder bookId( String bookId) {
            this.bookId = bookId;
            return this;
        }

        public Builder  customerId( String  customerId) {
            this.customerId =  customerId;
            return this;
        }

        public Comment build() {
            return new Comment(this);
        }

        public Builder copy(Comment comment) {
            this.commentId=comment.commentId;
            this.bookId=comment.bookId;
            this.customerId=comment.customerId;
            return this;
        }
    }

    @Override
    public String toString() {
        return "Comment{" +
                "comment Id='" + commentId + '\'' +
                ",book Id'" + bookId + '\'' +
                ", customer Id'" + customerId + '\'' +
                '}';
    }
}
