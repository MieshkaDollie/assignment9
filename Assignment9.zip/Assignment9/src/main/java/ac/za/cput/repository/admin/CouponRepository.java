package ac.za.cput.repository.admin;

import ac.za.cput.domain.admin.Coupon;
import ac.za.cput.repository.IRepository;

import java.util.Set;

public interface CouponRepository extends IRepository<Coupon,String> {

    Set<Coupon> getAll();
}
