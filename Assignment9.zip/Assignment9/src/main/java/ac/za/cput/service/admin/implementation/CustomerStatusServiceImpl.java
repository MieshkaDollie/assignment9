package ac.za.cput.service.admin.implementation;

import ac.za.cput.domain.admin.CustomerStatus;
import ac.za.cput.repository.admin.CustomerStatusRepository;
import ac.za.cput.repository.admin.implementation.CustomerStatusRepositoryImpl;
import ac.za.cput.service.admin.CustomerStatusService;

import java.util.Set;

public class CustomerStatusServiceImpl implements CustomerStatusService {

    private static CustomerStatusServiceImpl service = null;
    private CustomerStatusRepository repository;

    private CustomerStatusServiceImpl() {
        this.repository = CustomerStatusRepositoryImpl.getRepository();
    }

    public static CustomerStatusServiceImpl getService(){
        if (service == null) service = new CustomerStatusServiceImpl();
        return service;
    }


    @Override
    public Set<CustomerStatus> getAll() {
        return this.repository.getAll();
    }

    @Override
    public CustomerStatus create(CustomerStatus customerStatus) {
        return this.repository.create(customerStatus);
    }

    @Override
    public CustomerStatus update(CustomerStatus customerStatus) {
        return this.repository.update(customerStatus);
    }

    @Override
    public void delete(String s) {
          this.repository.delete(s);
    }

    @Override
    public CustomerStatus read(String s) {
        return null;
    }
}
