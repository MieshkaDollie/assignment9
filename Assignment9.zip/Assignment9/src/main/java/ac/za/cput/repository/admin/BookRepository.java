package ac.za.cput.repository.admin;

import ac.za.cput.domain.admin.Book;
import ac.za.cput.repository.IRepository;

import java.util.Set;

public interface BookRepository extends IRepository<Book,String> {

    Set<Book> getAll();
}
