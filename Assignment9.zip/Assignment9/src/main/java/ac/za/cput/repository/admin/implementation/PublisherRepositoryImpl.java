package ac.za.cput.repository.admin.implementation;

import ac.za.cput.domain.admin.Publisher;
import ac.za.cput.repository.admin.PublisherRepository;

import java.util.HashSet;
import java.util.Set;

public class PublisherRepositoryImpl implements PublisherRepository {

    private static PublisherRepositoryImpl repository = null;
    private Set<Publisher> publishers;

    private PublisherRepositoryImpl (){
        this.publishers = new HashSet<>();
    }

    private Publisher findPublisher(final String publisherCode) {
        return this.publishers.stream()
                .filter(publisher ->publisher.getCode().trim().equals(publisherCode))
                .findAny()
                .orElse(null);
    }

    public static PublisherRepositoryImpl getRepository() {
        if (repository == null) repository = new PublisherRepositoryImpl();
        return repository;
    }

    @Override
    public Set<Publisher> getAll() {
        return publishers;
    }

    @Override
    public Publisher create(Publisher publisher) {
        this.publishers.add(publisher);

        return publisher;
    }

    @Override
    public Publisher update(Publisher publisher) {
        Publisher toDelete = findPublisher(publisher.getCode());
        if(toDelete != null) {
            this.publishers.remove(toDelete);
            return create(publisher);
        }
        return null;
    }

    @Override
    public void delete(String s) {
        Publisher publisher= findPublisher(s);
        if (publisher != null) this.publishers.remove(publisher);
    }

    @Override
    public Publisher read(String s) {
        Publisher publisher= findPublisher(s);
        return  publisher;
    }
}
