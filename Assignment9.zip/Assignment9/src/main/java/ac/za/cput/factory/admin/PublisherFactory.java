package ac.za.cput.factory.admin;

import ac.za.cput.domain.admin.Publisher;

public class PublisherFactory {

    public static Publisher getPublisher(String code, String name) {
        return new Publisher.Builder().code(code)
                .name(name)
                .build();
    }
}
