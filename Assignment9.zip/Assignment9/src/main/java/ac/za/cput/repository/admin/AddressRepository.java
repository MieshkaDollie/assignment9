package ac.za.cput.repository.admin;

import ac.za.cput.domain.admin.Address;
import ac.za.cput.repository.IRepository;

import java.util.List;



public interface AddressRepository extends IRepository<Address,String> {

    List<Address> getAll();
}
