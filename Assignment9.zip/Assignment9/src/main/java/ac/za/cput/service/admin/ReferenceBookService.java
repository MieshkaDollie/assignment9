package ac.za.cput.service.admin;

import ac.za.cput.domain.admin.ReferenceBook;
import ac.za.cput.service.IService;

import java.util.Set;

public interface ReferenceBookService extends IService<ReferenceBook,String> {
    Set<ReferenceBook> getAll();
}

