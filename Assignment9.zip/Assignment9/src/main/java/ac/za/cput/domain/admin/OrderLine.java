package ac.za.cput.domain.admin;

public class OrderLine {

    private String orderNum,bookID,description;
    private double amount;


    private OrderLine(){}

    private OrderLine(Builder builder){
        this.orderNum=builder.orderNum;
        this.bookID = builder.bookID;
        this.description=builder.description;
        this.amount = builder.amount;
    }

    public String getOrderNum(){ return orderNum;}

    public String getBookID(){ return bookID;}

    public String getDescription(){ return description;}

    public double getAmount(){
        return amount;
    }

    public static class Builder {

        private String orderNum,bookID,description;
        private double amount;

        public Builder orderNum(String orderNum) {
            this.orderNum = orderNum;
            return this;
        }

        public Builder bookID(String bookID) {
            this.bookID = bookID;
            return this;
        }

        public Builder description (String description) {
            this.description = description;
            return this;
        }

        public Builder amount(double amount) {
            this.amount = amount;
            return this;
        }


        public OrderLine build() {
            return new OrderLine(this);
        }

        public Builder copy(OrderLine orderLine) {
            this.orderNum=orderLine.orderNum;
            this.bookID=orderLine.bookID;
            this.amount=orderLine.amount;
            this.description=orderLine.description;

            return this;
        }

    }

    @Override
    public String toString() {
        return "OrderLine{" +
                " book id='" + bookID + '\'' +
                ", amount='" + amount + '\'' +
                ",description=" + description +
                '}';
    }

}
