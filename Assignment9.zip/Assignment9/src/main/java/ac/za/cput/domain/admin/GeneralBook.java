package ac.za.cput.domain.admin;

public class GeneralBook {

    private String id,title;

    private GeneralBook(){}

    private GeneralBook(Builder builder){

        this.id = builder.id;
        this.title = builder.title;

    }

    public String getBookId(){ return id;}

    public String getTitle(){
        return title;
    }

    public static class Builder {

        private String id, title;

        public Builder id(String bookId){
            this.id=bookId;
            return  this;
        }

        public Builder title( String bookTitle) {
            this.title = bookTitle;
            return this;
        }

        public GeneralBook build() {
            return new GeneralBook(this);
        }

        public Builder copy(GeneralBook generalBook) {
            this.id=generalBook.id;
            this.title=generalBook.title;
            return this;
        }

    }

    public String toString() {
        return "Book{" +"book id= "+ id +
                "title='" + title + '\'' +
                '}';
    }
}
