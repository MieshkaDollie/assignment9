package ac.za.cput.repository.admin;

import ac.za.cput.domain.admin.Payment;
import ac.za.cput.repository.IRepository;

import java.util.Set;

public interface PaymentRepository extends IRepository<Payment,String> {
    Set<Payment> getAll();
}
