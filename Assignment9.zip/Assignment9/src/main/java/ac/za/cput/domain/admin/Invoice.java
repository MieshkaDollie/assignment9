package ac.za.cput.domain.admin;

public class Invoice {

    private String number;
    private double amount;

    private Invoice(){}

    private Invoice(Builder builder){
        this.number = builder.number;
        this.amount = builder.amount;
    }

    public String getNumber(){ return number;}

    public double getAmount(){
        return amount;
    }

    public static class Builder {

        private String number;
        private double amount;

        public Builder number(String number){
            this.number=number;
            return  this;
        }

        public Builder amount( double amount) {
            this.amount = amount;
            return this;
        }

        public Invoice build() {
            return new Invoice(this);
        }

        public Builder copy(Invoice invoice) {
            this.number=invoice.number;
            this.amount=invoice.amount;
            return this;
        }

    }


    public String toString() {
        return "Invoice{" +"number= "+ number +
                "amount='" + amount + '\'' +
                '}';
    }
}
