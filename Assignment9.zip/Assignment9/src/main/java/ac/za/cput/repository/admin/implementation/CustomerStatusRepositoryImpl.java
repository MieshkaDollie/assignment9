package ac.za.cput.repository.admin.implementation;

import ac.za.cput.domain.admin.CustomerStatus;
import ac.za.cput.repository.admin.CustomerStatusRepository;

import java.util.HashSet;
import java.util.Set;

public class CustomerStatusRepositoryImpl implements CustomerStatusRepository {

    private static CustomerStatusRepositoryImpl repository = null;
    private Set<CustomerStatus> customerStatuses;

    private CustomerStatusRepositoryImpl (){
        this.customerStatuses = new HashSet<>();
    }

    private CustomerStatus findCustomerStatus(final String customerID) {
        return this.customerStatuses.stream()
                .filter(customerStatus ->customerStatus.getCustomerId().trim().equals(customerID))
                .findAny()
                .orElse(null);
    }

    public static CustomerStatusRepositoryImpl getRepository(){
        if (repository == null) repository = new CustomerStatusRepositoryImpl();
        return repository;
    }
    @Override
    public Set<CustomerStatus> getAll() {
        return customerStatuses;
    }

    @Override
    public CustomerStatus create(CustomerStatus customerStatus) {
        this.customerStatuses.add(customerStatus);

        return customerStatus;
    }

    @Override
    public CustomerStatus update(CustomerStatus customerStatus) {
        CustomerStatus toDelete = findCustomerStatus(customerStatus.getCustomerId());
        if(toDelete != null) {
            this.customerStatuses.remove(toDelete);
            return create(customerStatus);
        }
        return null;
    }

    @Override
    public void delete(String s) {
        CustomerStatus customerStatus= findCustomerStatus(s);
        if (customerStatus != null) this.customerStatuses.remove(customerStatus);
    }

    @Override
    public CustomerStatus read(String s) {
        CustomerStatus customerStatus=findCustomerStatus(s);
        return customerStatus;
    }
}
