package ac.za.cput.repository.admin.implementation;

import ac.za.cput.domain.admin.GeneralBook;
import ac.za.cput.repository.admin.GeneralBookRepository;

import java.util.HashSet;
import java.util.Set;

public class GeneralBookRepositoryImpl implements GeneralBookRepository {

    private static GeneralBookRepositoryImpl repository = null;
    private Set<GeneralBook> generalBooks;

    private GeneralBookRepositoryImpl (){
        this.generalBooks = new HashSet<>();
    }

    private GeneralBook findGeneralBook(final String bookID) {
        return this.generalBooks.stream()
                .filter(generalBook ->generalBook.getBookId().trim().equals(bookID))
                .findAny()
                .orElse(null);
    }

    public static GeneralBookRepositoryImpl getRepository() {
        if (repository == null) repository = new GeneralBookRepositoryImpl();
        return repository;
    }

    @Override
    public Set<GeneralBook> getAll() {
        return this.generalBooks;
    }

    @Override
    public GeneralBook create(GeneralBook generalBook) {
        this.generalBooks.add(generalBook);

        return generalBook;
    }

    @Override
    public GeneralBook update(GeneralBook generalBook) {
        GeneralBook toDelete = findGeneralBook(generalBook.getBookId());
        if(toDelete != null) {
            this.generalBooks.remove(toDelete);
            return create(generalBook);
        }
        return null;
    }

    @Override
    public void delete(String s) {
        GeneralBook generalBook= findGeneralBook(s);
        if (generalBook != null) this.generalBooks.remove(generalBook);
    }

    @Override
    public GeneralBook read(String s) {
        GeneralBook generalBook=findGeneralBook(s);
        return generalBook;
    }
}
