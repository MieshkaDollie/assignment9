package ac.za.cput.service.admin.implementation;

import ac.za.cput.domain.admin.OrderStatus;
import ac.za.cput.service.admin.OrderStatusService;

import java.util.Set;

public class OrderStatusServiceImpl implements OrderStatusService {
    @Override
    public Set<OrderStatus> getAll() {
        return null;
    }

    @Override
    public OrderStatus create(OrderStatus orderStatus) {
        return null;
    }

    @Override
    public OrderStatus update(OrderStatus orderStatus) {
        return null;
    }

    @Override
    public void delete(String s) {

    }

    @Override
    public OrderStatus read(String s) {
        return null;
    }
}
