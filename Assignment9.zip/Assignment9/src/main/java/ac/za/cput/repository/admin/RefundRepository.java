package ac.za.cput.repository.admin;

import ac.za.cput.domain.admin.Refund;
import ac.za.cput.repository.IRepository;

import java.util.Set;

public interface RefundRepository extends IRepository<Refund,String> {
    Set<Refund> getAll();
}
