package ac.za.cput.service.admin.implementation;

import ac.za.cput.domain.admin.Cart;
import ac.za.cput.repository.admin.CartRepository;
import ac.za.cput.repository.admin.implementation.CartRepositoryImpl;
import ac.za.cput.service.admin.CartService;

import java.util.Set;

public class CartServiceImpl implements CartService {

    private static CartServiceImpl service = null;
    private CartRepository repository;

    private CartServiceImpl() {
        this.repository = CartRepositoryImpl.getRepository();
    }

    public static CartServiceImpl getService(){
        if (service == null) service = new CartServiceImpl();
        return service;
    }


    @Override
    public Set<Cart> getAll() {
        return this.repository.getAll();
    }

    @Override
    public Cart create(Cart cart) {
        return this.create(cart);
    }

    @Override
    public Cart update(Cart cart) {
        return this.update(cart);
    }

    @Override
    public void delete(String s) {
          this.repository.delete(s);
    }

    @Override
    public Cart read(String s) {
        return this.repository.read(s);
    }
}
