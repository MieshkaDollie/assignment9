package ac.za.cput.factory.admin;

import ac.za.cput.domain.admin.Refund;

public class RefundFactory {

    public static Refund getRefund(String id, double amount) {
        return new Refund.Builder().id(id)
                .amount(amount)
                .build();
    }
}
