package ac.za.cput.domain.admin;

public class Payment {

    private String id;
    private double amount;


    private Payment (){}

    private Payment (Builder builder){

        this.id = builder.id;
        this.amount = builder.amount;

    }

    public String getId() {
        return id;
    }

    public double getAmount() {
        return amount;
    }

    public static class Builder {

        private String id;
        private double amount;


        public Builder id(String id) {
            this.id =id;
            return this;
        }

        public Builder amount(double amount) {
            this.amount = amount;
            return this;
        }
        public Payment build() {
            return new Payment(this);
        }

        public Builder copy(Payment payment) {
            this.id=payment.id;
            this.amount=payment.amount;
            return this;
        }
    }

    @Override
    public String toString() {
        return "Payment{" +
                "id='" + id + '\'' +
                ", amount='" + amount + '\'' +
                '}';
    }
}

