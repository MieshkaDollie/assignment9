package ac.za.cput.repository.admin;

import ac.za.cput.domain.admin.Invoice;
import ac.za.cput.repository.IRepository;

import java.util.Set;

public interface InvoiceRepository extends IRepository<Invoice,String> {
    Set<Invoice> getAll();
}
