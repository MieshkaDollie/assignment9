package ac.za.cput.service.admin;

import ac.za.cput.domain.admin.GeneralBook;
import ac.za.cput.service.IService;

import java.util.Set;

public interface GeneralBookService extends IService<GeneralBook,String> {
    Set<GeneralBook> getAll();
}

