package ac.za.cput.service.admin.implementation;

import ac.za.cput.domain.admin.Payment;
import ac.za.cput.repository.admin.PaymentRepository;
import ac.za.cput.repository.admin.implementation.PaymentRepositoryImpl;
import ac.za.cput.service.admin.PaymentService;

import java.util.Set;

public class PaymentServiceImpl implements PaymentService {

    private static PaymentServiceImpl service = null;
    private PaymentRepository repository;

    private PaymentServiceImpl() {
        this.repository = PaymentRepositoryImpl.getRepository();
    }

    public static PaymentServiceImpl getService(){
        if (service == null) service = new PaymentServiceImpl();
        return service;
    }


    @Override
    public Set<Payment> getAll() {
        return this.repository.getAll();
    }

    @Override
    public Payment create(Payment payment) {
        return this.repository.create(payment);
    }

    @Override
    public Payment update(Payment payment) {
        return this.repository.update(payment);
    }

    @Override
    public void delete(String s) {
      this.repository.delete(s);
    }

    @Override
    public Payment read(String s) {
        return this.repository.read(s);
    }
}
