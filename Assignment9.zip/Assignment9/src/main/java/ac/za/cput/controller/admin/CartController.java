package ac.za.cput.controller.admin;

import ac.za.cput.domain.admin.Cart;
import ac.za.cput.service.admin.CartService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.*;

import java.util.Set;

@RestController
@RequestMapping("/cart")
public class CartController {
    @Autowired
    @Qualifier("ServiceImpl")
    private CartService service;

    @PostMapping("/create")
    @ResponseBody
    public Cart create(Cart cart) {
        return service.create(cart);
    }

    @PostMapping("/update")
    @ResponseBody
    public Cart update(Cart cart) {
        return service.update(cart);
    }

    @GetMapping("/delete/{id}")
    @ResponseBody
    public void delete(@PathVariable String id) {
        service.delete(id);

    }

    @GetMapping("/read/{id}")
    @ResponseBody
    public Cart read(@PathVariable String id) {
        return service.read(id);
    }

    @GetMapping("/read/all")
    @ResponseBody
    public Set<Cart> getAll() {
        return service.getAll();
    }


}
