package ac.za.cput.service.admin.implementation;

import ac.za.cput.domain.admin.Publisher;
import ac.za.cput.repository.admin.PublisherRepository;
import ac.za.cput.repository.admin.implementation.PublisherRepositoryImpl;
import ac.za.cput.service.admin.PublisherService;

import java.util.Set;

public class PublisherServiceImpl implements PublisherService {

    private static PublisherServiceImpl service = null;
    private PublisherRepository repository;

    private PublisherServiceImpl() {
        this.repository = PublisherRepositoryImpl.getRepository();
    }

    public static PublisherServiceImpl getService(){
        if (service == null) service = new PublisherServiceImpl();
        return service;
    }


    @Override
    public Set<Publisher> getAll() {
        return this.repository.getAll();
    }

    @Override
    public Publisher create(Publisher publisher) {
        return this.repository.create(publisher);
    }

    @Override
    public Publisher update(Publisher publisher) {
        return this.repository.update(publisher);
    }

    @Override
    public void delete(String s) {
     this.repository.delete(s);
    }

    @Override
    public Publisher read(String s) {
        return this.repository.read(s);
    }
}
