package ac.za.cput.factory.admin;

import ac.za.cput.domain.admin.ReferenceBook;

public class ReferenceBookFactory {


    public static ReferenceBook getReferenceBook(String  id, String title) {
        return new ReferenceBook.Builder().id(id)
                .title(title)
                .build();
    }
}
