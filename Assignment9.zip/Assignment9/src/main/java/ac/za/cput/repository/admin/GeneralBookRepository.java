package ac.za.cput.repository.admin;

import ac.za.cput.domain.admin.GeneralBook;
import ac.za.cput.repository.IRepository;

import java.util.Set;

public interface GeneralBookRepository extends IRepository<GeneralBook,String> {
    Set<GeneralBook> getAll();
}
