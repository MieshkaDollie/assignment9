package ac.za.cput.repository.admin.implementation;

import ac.za.cput.domain.admin.ReferenceBook;
import ac.za.cput.repository.admin.ReferenceBookRepository;

import java.util.HashSet;
import java.util.Set;

public class ReferenceBookRepositoryImpl implements ReferenceBookRepository {

    private static ReferenceBookRepositoryImpl repository = null;
    private Set<ReferenceBook> referenceBooks;

    private ReferenceBookRepositoryImpl (){
        this.referenceBooks = new HashSet<>();
    }

    private ReferenceBook findReferenceBook(final String bookID) {
        return this.referenceBooks.stream()
                .filter(referenceBook -> referenceBook.getBookId().trim().equals(bookID))
                .findAny()
                .orElse(null);
    }

    public static ReferenceBookRepositoryImpl getRepository() {
        if (repository == null) repository = new ReferenceBookRepositoryImpl();
        return repository;
    }

    @Override
    public Set<ReferenceBook> getAll() {
        return referenceBooks;
    }

    @Override
    public ReferenceBook create(ReferenceBook referenceBook) {
        this.referenceBooks.add(referenceBook);
        return  referenceBook;
    }

    @Override
    public ReferenceBook update(ReferenceBook referenceBook) {
        ReferenceBook toDelete = findReferenceBook(referenceBook.getBookId());
        if(toDelete != null) {
            this.referenceBooks.remove(toDelete);
            return create(referenceBook);
        }
        return null;
    }

    @Override
    public void delete(String s) {
        ReferenceBook referenceBook= findReferenceBook(s);
        if (referenceBook != null) this.referenceBooks.remove(referenceBook);
    }

    @Override
    public ReferenceBook read(String s) {
        ReferenceBook referenceBook= findReferenceBook(s);
        return referenceBook;
    }
}
