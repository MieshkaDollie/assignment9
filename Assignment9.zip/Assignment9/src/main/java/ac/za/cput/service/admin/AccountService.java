package ac.za.cput.service.admin;

import ac.za.cput.domain.admin.Account;
import ac.za.cput.service.IService;

import java.util.Set;


public interface AccountService extends IService<Account,String> {
    Set<Account> getAll();
}
