package ac.za.cput.repository.admin.implementation;

import ac.za.cput.repository.admin.OrderStatus;

import java.util.HashSet;
import java.util.Set;

public class OrderStatusRepositoryImpl  {
/*

    private static OrderStatusRepositoryImpl repository = null;
    private Set<OrderStatus> orderStatuses;

    private OrderStatusRepositoryImpl (){
        this.orderStatuses = new HashSet<>();
    }

    private OrderStatus findOrderStatus(final String num) {

        return this.orderStatuses.stream()
                .filter(orderStatus -> orderStatus.getOrderNumber().trim().equals(num))
                .findAny()
                .orElse(null);
    }

    public static OrderStatusRepositoryImpl getRepository() {
        if (repository == null) repository = new OrderStatusRepositoryImpl();
        return repository;
    }

    @Override
    public Set<OrderStatus> getAll() {
        return orderStatuses;
    }

    @Override
    public OrderStatus create(OrderStatus orderStatus) {
        this.orderStatuses.add(orderStatus);
        return orderStatus;
    }

    @Override
    public OrderStatus update(OrderStatus orderStatus) {
        OrderStatus toDelete = findOrderStatus(orderStatus.getOrderNumber());
        if(toDelete != null) {
            this.orderStatuses.remove(toDelete);
            return create(orderStatus);
        }
        return null;
    }

    @Override
    public void delete(String s) {
        OrderStatus orderStatus= findOrderStatus(s);
        if (orderStatus != null) this.orderStatuses.remove(orderStatus);
    }

    @Override
    public OrderStatus read(String s) {
        OrderStatus orderStatus= findOrderStatus(s);
        return orderStatus;
    } */
}
