package ac.za.cput.repository.people;

import ac.za.cput.domain.people.Administrator;
import ac.za.cput.repository.IRepository;

import java.util.Set;

public interface AdministratorRepository extends IRepository<Administrator,String> {
    Set<Administrator> getAll();
}
