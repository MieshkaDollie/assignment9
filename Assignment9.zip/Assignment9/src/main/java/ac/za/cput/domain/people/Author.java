package ac.za.cput.domain.people;

import ac.za.cput.domain.admin.Book;

import java.util.Set;

public class Author {

    private String fName,lName,bio;
    private int age;
    private Set<Book> book;

    private Author(){}



    private Author(Builder builder) {
        this.fName=builder.fName;
        this.lName = builder.lName;
        this.age = builder.age;
        this.bio = builder.bio;

    }

    public String getFirsName(){ return fName;}

    public String getLastName(){ return lName;}

    public int getAge(){ return age;}

    public String getBio(){ return bio;}


    public static class Builder {

        private String fName,lName,bio;
        private int age;
        private Set<Book> book;

        public Builder firstName(String fName){
            this.fName=fName;
            return  this;
        }

        public Builder lastName(String lName){
            this.lName=lName;
            return  this;
        }

        public Builder age(int age){
            this.age=age;
            return  this;
        }

        public Builder bio(String bio){
            this.bio=bio;
            return  this;
        }

        public Author build() {
            return new Author(this);
        }

        public Builder copy(Author author) {
            this.age= author.age;
            this.fName= author.fName;
            this.bio= author.bio;
            this.lName= author.lName;
            return this;
        }

    }

    @Override
    public String toString() {
        return "Author{" +
                "first name='" + fName + '\'' +
                ",last name='" + lName + '\'' +
                ",age ='" + age + '\'' +
                ", bio='" + bio  +
                '}';
}

}
