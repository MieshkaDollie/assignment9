package ac.za.cput.service.admin.implementation;

import ac.za.cput.domain.admin.Invoice;
import ac.za.cput.repository.admin.InvoiceRepository;
import ac.za.cput.repository.admin.implementation.InvoiceRepositoryImpl;
import ac.za.cput.service.admin.InvoiceService;

import java.util.Set;

public class InvoiceServiceImpl implements InvoiceService {

    private static InvoiceServiceImpl service = null;
    private InvoiceRepository repository;

    private InvoiceServiceImpl() {
        this.repository = InvoiceRepositoryImpl.getRepository();
    }

    public static InvoiceServiceImpl getService(){
        if (service == null) service = new InvoiceServiceImpl();
        return service;
    }


    @Override
    public Set<Invoice> getAll() {
        return this.repository.getAll();
    }

    @Override
    public Invoice create(Invoice invoice) {
        return this.repository.create(invoice);
    }

    @Override
    public Invoice update(Invoice invoice) {
        return this.repository.update(invoice);
    }

    @Override
    public void delete(String s) {
         this.repository.delete(s);
    }

    @Override
    public Invoice read(String s) {
        return this.repository.read(s);
    }
}
