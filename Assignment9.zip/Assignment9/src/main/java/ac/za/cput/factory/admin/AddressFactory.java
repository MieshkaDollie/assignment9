package ac.za.cput.factory.admin;

import ac.za.cput.domain.admin.Address;

public class AddressFactory {



    public static Address getAddress(String type, String street, String road,String city,String country) {
        return new Address.Builder().type(type)
                .street(street)
                .road(road)
                .city(city)
                .country(country)
                .build();
    }
}
