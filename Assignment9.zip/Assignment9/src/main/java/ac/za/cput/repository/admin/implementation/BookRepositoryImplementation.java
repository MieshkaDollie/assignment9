package ac.za.cput.repository.admin.implementation;

import ac.za.cput.domain.admin.Book;
import ac.za.cput.repository.admin.BookRepository;

import java.util.*;


public class BookRepositoryImplementation implements BookRepository {



    private static BookRepositoryImplementation repository = null;
    private Set<Book> book;

    private BookRepositoryImplementation (){
        this.book = new HashSet<>();
    }

    private Book findBook(final String bookID) {
        return this.book.stream()
                .filter(book ->book.getBookId().trim().equals(bookID))
                .findAny()
                .orElse(null);
    }

    public static BookRepositoryImplementation getRepository(){
        if (repository == null) repository = new BookRepositoryImplementation();
        return repository;
    }


    @Override
    public Set<Book> getAll() {
        return book;
    }

    @Override
    public Book create(Book book) {

        this.book.add(book);


        return book;
    }

    @Override
    public Book update(Book book) {
        Book toDelete = findBook(book.getBookId());
        if(toDelete != null) {
            this.book.remove(toDelete);
            return create(book);
        }
        return null;
    }


    @Override
    public void delete(String s) {

        Book book = findBook(s);
        if (book != null) this.book.remove(book);
    }

    @Override
    public Book read(String s) {
       Book book=findBook(s);
        return book;
    }
}
