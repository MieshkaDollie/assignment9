package ac.za.cput.service.admin;

import ac.za.cput.domain.admin.Report;
import ac.za.cput.service.IService;

import java.util.Set;

public interface ReportService extends IService<Report,String> {
    Set<Report> getAll();
}

