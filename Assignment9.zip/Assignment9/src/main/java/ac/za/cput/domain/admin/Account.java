package ac.za.cput.domain.admin;

import ac.za.cput.domain.people.Customer;

import java.util.Set;

public class Account {

    private String id,holderName;
    private Set<Customer> cust;

    private Account(){}

    private Account(Builder builder) {
        this.id=builder.id;
        this.holderName = builder.holderName;
    }


    public String getID() {
        return id;
    }

    public String getHolderName() {
        return holderName;
    }


    public static class Builder {

        private String id,holderName;

        public Builder id(String id) {
            this.id = id;
            return this;
        }

        public Builder holderName(String holdername) {
            this.holderName = holdername;
            return this;
        }



        public Account build() {
            return new Account(this);
        }

        public Builder copy(Account account) {
            this.id=account.id;
            this.holderName = account.holderName;

            return this;
        }
    }

    @Override
    public String toString() {
        return "Account{" +
                "id='" + id + '\'' +
                ",holder name ='" + holderName + '\'' +
                '}';
    }
}
