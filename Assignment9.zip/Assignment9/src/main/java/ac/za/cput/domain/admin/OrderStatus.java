package ac.za.cput.domain.admin;

public class OrderStatus {

    private String orderNum;
    private String status;

    private OrderStatus(){}

    private OrderStatus(Builder builder){


        this.orderNum = builder.orderNum;
        this.status = builder.status;
    }

    public String getOrderNumber() {
        return orderNum;
    }

    public String getStatus() {
        return status;
    }

    public static class Builder {

        private String orderNum;
        private String status;


        public Builder orderNumber(String orderNumber) {
            this.orderNum= orderNumber;
            return this;
        }

        public Builder customerId(String status) {
            this.status = status;
            return this;
        }
        public OrderStatus build() {
            return new OrderStatus(this);
        }

        public Builder copy(OrderStatus orderStatus) {
            this.orderNum=orderStatus.orderNum;
            this.status=orderStatus.status;

            return this;
        }
    }

    @Override
    public String toString() {
        return "OrderStatus{" +
                "order number='" + orderNum + '\'' +
                ", status='" + status + '\'' +
                '}';
    }
}
