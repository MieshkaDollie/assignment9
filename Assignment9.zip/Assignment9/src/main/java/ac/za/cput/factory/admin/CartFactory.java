package ac.za.cput.factory.admin;

import ac.za.cput.domain.admin.Cart;

public class CartFactory {

    public static Cart getCart(String id,String bookId, int amount, String category) {
        return new Cart.Builder().id(id)
                .bookId(bookId)
                .amount(amount)
                .category(category)
                .build();
    }
}
