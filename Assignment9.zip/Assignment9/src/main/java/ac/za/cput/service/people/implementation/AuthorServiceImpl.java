package ac.za.cput.service.people.implementation;

import ac.za.cput.domain.people.Author;
import ac.za.cput.repository.people.AuthorRepository;
import ac.za.cput.repository.people.implementation.AuthorRepositoryImpl;
import ac.za.cput.service.people.AuthorService;

import java.util.Set;

public class AuthorServiceImpl implements AuthorService {

    private static AuthorServiceImpl service = null;
    private AuthorRepository repository;

    private AuthorServiceImpl() {
        this.repository = AuthorRepositoryImpl.getRepository();
    }

    public static AuthorServiceImpl getService(){
        if (service == null) service = new AuthorServiceImpl();
        return service;
    }



    @Override
    public Set<Author> getAll() {
        return this.repository.getAll();
    }

    @Override
    public Author create(Author author) {
        return this.repository.create(author);
    }

    @Override
    public Author update(Author author) {
        return this.repository.update(author);
    }

    @Override
    public void delete(String s) {
     this.repository.delete(s);
    }

    @Override
    public Author read(String s) {
        return this.repository.read(s);
    }
}
