package ac.za.cput.service.admin;

import ac.za.cput.domain.admin.Order;
import ac.za.cput.service.IService;

import java.util.Set;

public interface OrderService extends IService<Order,String> {
    Set<Order> getAll();
}

