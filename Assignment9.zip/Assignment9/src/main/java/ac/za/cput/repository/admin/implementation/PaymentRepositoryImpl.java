package ac.za.cput.repository.admin.implementation;

import ac.za.cput.domain.admin.Payment;
import ac.za.cput.repository.admin.PaymentRepository;

import java.util.HashSet;
import java.util.Set;

public class PaymentRepositoryImpl implements PaymentRepository {

    private static PaymentRepositoryImpl repository = null;
    private Set<Payment> payments;

    private PaymentRepositoryImpl (){
        this.payments = new HashSet<>();
    }

    private Payment findPayment(final String paymentID) {
        return this.payments.stream()
                .filter(payment ->payment.getId().trim().equals(paymentID))
                .findAny()
                .orElse(null);
    }

    public static PaymentRepositoryImpl getRepository() {
        if (repository == null) repository = new PaymentRepositoryImpl();
        return repository;
    }

    @Override
    public Set<Payment> getAll() {
        return payments;
    }

    @Override
    public Payment create(Payment payment) {
        this.payments.add(payment);

        return payment;
    }

    @Override
    public Payment update(Payment payment) {
        Payment toDelete = findPayment(payment.getId());
        if(toDelete != null) {
            this.payments.remove(toDelete);
            return create(payment);
        }
        return null;
    }

    @Override
    public void delete(String s) {
        Payment payment= findPayment(s);
        if (payment != null) this.payments.remove(payment);
    }

    @Override
    public Payment read(String s) {
        Payment payment= findPayment(s);
        return payment;
    }
}
