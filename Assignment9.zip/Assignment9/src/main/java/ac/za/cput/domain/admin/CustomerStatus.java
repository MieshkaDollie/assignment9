package ac.za.cput.domain.admin;

public class CustomerStatus {

    private String customerid,customerStatus;

    private CustomerStatus(){}

    private CustomerStatus(Builder builder) {
        this.customerid=builder.customerid;
        this.customerStatus = builder.customerStatus;
    }

    public String getCustomerId(){return customerid;}

    public String getCustomerStatus() {
        return customerStatus;
    }

    public static class Builder {

        private String customerid,customerStatus;

    public Builder customerID( String customerid) {
        this.customerid = customerid;
        return this;
    }

    public Builder  customerStatus( String  customerstatus) {
        this.customerStatus =  customerstatus;
        return this;
    }

        public CustomerStatus build() {
            return new CustomerStatus(this);
        }

        public Builder copy(CustomerStatus customerStatus) {
            this.customerid=customerStatus.customerid;
            this.customerStatus=customerStatus.customerStatus;
            return this;
        }

    }

    @Override
    public String toString() {
        return "Customer Status{" +
                "custoemr id='" + customerid + '\'' +
                ", custoemr status'" + customerStatus + '\'' +
                '}';
    }
}
