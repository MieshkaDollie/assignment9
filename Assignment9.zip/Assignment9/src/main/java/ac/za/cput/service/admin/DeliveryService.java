package ac.za.cput.service.admin;

import ac.za.cput.domain.admin.Delivery;
import ac.za.cput.service.IService;

import java.util.Set;

public interface DeliveryService extends IService<Delivery,String> {
    Set<Delivery> getAll();
}
