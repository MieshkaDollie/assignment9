package ac.za.cput.factory.people;

import ac.za.cput.domain.people.Administrator;

public class AdministratorFactory {


    public static Administrator getAdministrator(String id, String fname,String sname) {
        return new Administrator.Builder().id(id)
                .fName(fname)
                .sName(sname)
                .build();
    }
}
