package ac.za.cput.controller.admin;

import ac.za.cput.domain.admin.Coupon;
import ac.za.cput.domain.admin.Delivery;
import ac.za.cput.service.admin.DeliveryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.*;

import java.util.Set;

@RestController
@RequestMapping("/delivery")
public class DeliveryController {


    @Autowired
    @Qualifier("ServiceImpl")
    private DeliveryService service;

    @PostMapping("/create")
    @ResponseBody
    public Delivery create(Delivery delivery) {
        return service.create(delivery);
    }

    @PostMapping("/update")
    @ResponseBody
    public Delivery update(Delivery delivery) {
        return service.update(delivery);
    }

    @GetMapping("/delete/{id}")
    @ResponseBody
    public void delete(@PathVariable String id) {
        service.delete(id);

    }

    @GetMapping("/read/{id}")
    @ResponseBody
    public Delivery read(@PathVariable String id) {
        return service.read(id);
    }

    @GetMapping("/read/all")
    @ResponseBody
    public Set<Delivery> getAll() {
        return service.getAll();
    }
}


