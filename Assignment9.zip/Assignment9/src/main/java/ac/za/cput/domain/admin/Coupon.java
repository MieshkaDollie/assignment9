package ac.za.cput.domain.admin;

public class Coupon {

    private String couponId,dateEff,dateLoseEff;

    private Coupon(){}

    private Coupon(Builder builder) {
        this.couponId=builder.couponId;
        this.dateEff = builder.dateEff;
        this.dateLoseEff= builder.dateLoseEff;

    }

    public String getcouponId(){return couponId;}

    public String getdateEff() {
        return dateEff;
    }


    public String getdateLoseEff() {
        return dateLoseEff;
    }

    public static class Builder {

        private String couponId,dateEff,dateLoseEff;

        public Builder couponId(String id){
            this.couponId=id;
            return this;
        }

        public Builder dateEff( String dateEff) {
            this.dateEff = dateEff;
            return this;
        }

        public Builder  dateLoseEff( String  dateLoseEff) {
            this.dateLoseEff =  dateLoseEff;
            return this;
        }

        public Coupon build() {
            return new Coupon(this);
        }

        public Builder copy(Coupon coupon ){
            this.couponId=coupon.couponId;
            this.dateEff=coupon.dateEff;
            this.dateLoseEff=coupon.dateLoseEff;
            return this;
        }
    }

    @Override
    public String toString() {
        return "Coupon{" +
                "coupon Id='" + couponId + '\'' +
                ",dateEff='" + dateEff + '\'' +
                ", dateLoseEff ='" + dateLoseEff + '\'' +
                '}';
    }
}
