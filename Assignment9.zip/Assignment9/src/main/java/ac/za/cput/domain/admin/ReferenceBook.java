package ac.za.cput.domain.admin;

public class ReferenceBook {

    private String id,title;

    private ReferenceBook(){}

    private ReferenceBook(Builder builder){

        this.id = builder.id;
        this.title = builder.title;

    }

    public String getBookId(){ return id;}

    public String getTitle(){
        return title;
    }

    public static class Builder {

        private String id, title;

        public Builder id(String bookId){
            this.id=bookId;
            return  this;
        }

        public Builder title( String bookTitle) {
            this.title = bookTitle;
            return this;
        }

        public ReferenceBook build() {
            return new ReferenceBook(this);
        }

        public Builder copy(ReferenceBook referenceBook) {
            this.id=referenceBook.id;
            this.title=referenceBook.title;
            return this;
        }

    }

    public String toString() {
        return "Book{" +"book id= "+ id +
                "title='" + title + '\'' +
                '}';
    }
}
