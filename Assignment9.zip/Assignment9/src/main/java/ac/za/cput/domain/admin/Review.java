package ac.za.cput.domain.admin;


public class Review {



    private String reviewId,customerId ,content;

    private Review(){}

    private Review(Builder builder) {
        this.reviewId=builder.reviewId;
        this.customerId = builder.customerId;
        this.content = builder.content;

    }

    public String getReviewId(){return reviewId;}

    public String getCustomerId(){return customerId;}

    public String getContent(){return content;}

    public static class Builder {


        private String reviewId, customerId, content;

        public Builder reviewId(String id) {
            this.reviewId = id;
            return this;
        }

        public Builder customerId(String id){
            this.customerId=id;
            return this;
        }

        public Builder content(String content){
            this.content=content;
            return this;
        }

        public Review build() {
            return new Review(this);
        }

        public Builder copy(Review review) {
            this.reviewId=review.reviewId;
            this.customerId=review.customerId;
            this.content=review.content;
            return this;
        }

    }

    @Override
    public String toString() {
        return "Review{" +
                "review id='" + reviewId + '\'' +
                ", customer id='" + customerId + '\'' +
                ", content='" + content + '\'' +
                '}';
    }
}
