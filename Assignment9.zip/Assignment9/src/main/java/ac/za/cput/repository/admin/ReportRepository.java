package ac.za.cput.repository.admin;

import ac.za.cput.domain.admin.Report;
import ac.za.cput.repository.IRepository;

import java.util.Set;

public interface ReportRepository extends IRepository<Report,String> {
    Set<Report> getAll();
}
