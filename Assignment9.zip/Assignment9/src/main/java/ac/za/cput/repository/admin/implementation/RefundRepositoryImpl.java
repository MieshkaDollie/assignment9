package ac.za.cput.repository.admin.implementation;

import ac.za.cput.domain.admin.Refund;
import ac.za.cput.repository.admin.RefundRepository;

import java.util.HashSet;
import java.util.Set;

public class RefundRepositoryImpl implements RefundRepository {


    private static RefundRepositoryImpl repository = null;
    private Set<Refund> refunds;

    private RefundRepositoryImpl (){
        this.refunds = new HashSet<>();
    }

    private Refund findRefund(final String refundID) {
        return this.refunds.stream()
                .filter(refund ->refund.id().trim().equals(refundID))
                .findAny()
                .orElse(null);
    }

    public static RefundRepositoryImpl getRepository() {
        if (repository == null) repository = new RefundRepositoryImpl();
        return repository;
    }

    @Override
    public Set<Refund> getAll() {
        return refunds;
    }

    @Override
    public Refund create(Refund refund) {
        this.refunds.add(refund);
        return refund;
    }

    @Override
    public Refund update(Refund refund) {
        Refund toDelete = findRefund(refund.id());
        if(toDelete != null) {
            this.refunds.remove(toDelete);
            return create(refund);
        }
        return null;
    }

    @Override
    public void delete(String s) {
        Refund refund= findRefund(s);
        if (refund != null) this.refunds.remove(refund);
    }

    @Override
    public Refund read(String s) {
        Refund refund= findRefund(s);
        return refund;
    }
}
