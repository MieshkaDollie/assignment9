package ac.za.cput.domain.admin;

public class Report {
    private String reportID;
    private String date, description;
    private double sale;

    private Report (){}

    private Report(Builder builder) {
        this.date=builder.date;
        this.description = builder.description;
        this.sale= builder.sale;
        this.reportID=builder.reportID;
    }

    public String getReportID() {
        return reportID;
    }

    public String getDate() {
        return date;
    }

    public String getDescription() {
        return description;
    }

    public double getSale() {
        return sale;
    }

    public static class Builder {
        private String reportID;
        private String date, description;
        private double sale;

        public Builder reportID(String  reportID) {
            this.reportID = reportID;
            return this;
        }

        public Builder date(String date) {
            this.date = date;
            return this;
        }

        public Builder description(String description) {
            this.description = description;
            return this;
        }

        public Builder sale(double sale) {
            this.sale = sale;
            return this;
        }

        public Report build() {
            return new Report(this);
        }

        public Builder copy(Report report) {
            this.reportID=report.reportID;
            this.date=report.date;
            this.description=report.description;
            this.sale=report.sale;
            return this;
        }

    }

    @Override
    public String toString() {
        return "Report{" +"report num='"+reportID+
                "date='" + date+ '\'' +
                ",dfescription ='" + description + '\'' +
                ",sale ='" + sale+ '\'' +
                '}';
    }

}
