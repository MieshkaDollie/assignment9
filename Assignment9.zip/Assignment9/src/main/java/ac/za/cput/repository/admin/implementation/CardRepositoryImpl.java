package ac.za.cput.repository.admin.implementation;

import ac.za.cput.domain.admin.Card;
import ac.za.cput.repository.admin.CardRepository;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class CardRepositoryImpl implements CardRepository {



    private static CardRepositoryImpl repository = null;
    private Set<Card> card;

    private CardRepositoryImpl (){
        this.card = new HashSet<>();
    }

    private Card findCard(final String number) {
        return this.card.stream()
                .filter(card -> card.getCardNumber().trim().equals(number))
                .findAny()
                .orElse(null);
    }

    public static CardRepositoryImpl getRepository(){
        if (repository == null) repository = new CardRepositoryImpl();
        return repository;
    }

    @Override
    public Set<Card> getAll() {
        return card;
    }

    @Override
    public Card create(Card card) {
        this.card.add(card);
        return card;
    }

    @Override
    public Card update(Card card) {
        Card toDelete = findCard(card.getCardNumber());
        if(toDelete != null) {
            this.card.remove(toDelete);
            return create(card);
        }
        return null;
    }

    @Override
    public void delete(String s) {
        Card card= findCard(s);
        if (card != null) this.card.remove(card);
    }

    @Override
    public Card read(String s) {
        Card card= findCard(s);
        return card;
    }
}
