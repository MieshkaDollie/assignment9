package ac.za.cput.factory.admin;

import ac.za.cput.domain.admin.Order;

public class OrderFactory {



    public static Order getOrder(String orderNumber,String custId,double amount, String description) {
        return new Order.Builder().orderNumber(orderNumber)
                .customerId(custId)
                .amount(amount)
                .description(description)
                .build();
    }
}
