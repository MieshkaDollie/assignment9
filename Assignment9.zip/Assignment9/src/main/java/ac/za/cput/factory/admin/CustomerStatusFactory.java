package ac.za.cput.factory.admin;

import ac.za.cput.domain.admin.CustomerStatus;

public class CustomerStatusFactory {



    public static CustomerStatus getCustomerStatus(String  id, String status) {
        return new CustomerStatus.Builder().customerID(id)
                .customerStatus(status)
                .build();
    }
}
