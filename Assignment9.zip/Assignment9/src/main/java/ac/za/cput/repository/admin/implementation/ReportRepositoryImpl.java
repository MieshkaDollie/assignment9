package ac.za.cput.repository.admin.implementation;

import ac.za.cput.domain.admin.Report;
import ac.za.cput.repository.admin.ReportRepository;

import java.util.HashSet;
import java.util.Set;

public class ReportRepositoryImpl implements ReportRepository {

    private static  ReportRepositoryImpl repository = null;
    private Set<Report> reports;

    private ReportRepositoryImpl (){
        this.reports = new HashSet<>();
    }

    private Report findReport(final String num) {

        return this.reports.stream()
                .filter(report -> report.getReportID().trim().equals(num))
                .findAny()
                .orElse(null);
    }

    public static ReportRepositoryImpl getRepository() {
        if (repository == null) repository = new ReportRepositoryImpl();
        return repository;
    }

    @Override
    public Set<Report> getAll() {
        return reports;
    }

    @Override
    public Report create(Report report) {
        this.reports.add(report);
        return report;
    }

    @Override
    public Report update(Report report) {
       Report toDelete = findReport(report.getReportID());
        if(toDelete != null) {
            this.reports.remove(toDelete);
            return create(report);
        }
        return null;
    }

    @Override
    public void delete(String s) {
        Report report= findReport(s);
        if (report != null) this.reports.remove(report);
    }

    @Override
    public Report read(String s) {
        Report report= findReport(s);
        return report;
    }
}
