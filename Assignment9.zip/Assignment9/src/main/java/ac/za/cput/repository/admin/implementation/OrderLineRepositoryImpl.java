package ac.za.cput.repository.admin.implementation;

import ac.za.cput.domain.admin.Invoice;
import ac.za.cput.domain.admin.Order;
import ac.za.cput.repository.admin.OrderLine;
import ac.za.cput.repository.admin.OrderRepository;

import java.util.HashSet;
import java.util.Set;

public class OrderLineRepositoryImpl /*implements OrderLine */{

/*


    private static OrderLineRepositoryImpl repository = null;
    private Set<OrderLine> orderLines;

    private OrderLineRepositoryImpl (){
        this.orderLines = new HashSet<>();
    }

    private OrderLine findOrderLine(final String num) {

        return this.orderLines.stream()
                .filter(orderLine -> orderLine.trim().equals(num))
                .findAny()
                .orElse(null);
    }

    public static OrderLineRepositoryImpl getRepository() {
        if (repository == null) repository = new OrderLineRepositoryImpl();
        return repository;
    }


    @Override
    public Set<OrderLine> getAll() {
        return orderLines;
    }

    @Override
    public OrderLine create(OrderLine orderLine) {
        this.orderLines.add(orderLine);
        return orderLine;
    }

    @Override
    public OrderLine update(OrderLine orderLine) {

        OrderLine toDelete = findOrderLine(orderLine.getOrderNum());
        if(toDelete != null) {
            this.orderLines.remove(toDelete);
            return create(orderLine);
        }
        return null;
    }

    @Override
    public void delete(String s) {
        OrderLine orderLine= findOrderLine(s);
        if (orderLine != null) this.orderLines.remove(orderLine);
    }

    @Override
    public OrderLine read(String s) {
        OrderLine orderLine= findOrderLine(s);
        return orderLine;
    } */
}
