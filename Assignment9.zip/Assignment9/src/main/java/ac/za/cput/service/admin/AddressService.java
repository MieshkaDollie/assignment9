package ac.za.cput.service.admin;

import ac.za.cput.domain.admin.Address;
import ac.za.cput.service.IService;

import java.util.List;


public interface AddressService extends IService<Address,String> {
    List<Address> getAll();
}

