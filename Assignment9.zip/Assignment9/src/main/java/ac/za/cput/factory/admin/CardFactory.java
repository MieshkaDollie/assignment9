package ac.za.cput.factory.admin;

import ac.za.cput.domain.admin.Card;

public class CardFactory {

    public static Card getCard(String cardNum,String cardOwner, String bank) {
        return new Card.Builder().cardNumber(cardNum)
                .cardOwner(cardOwner)
                .bank(bank)
                .build();
    }
}
