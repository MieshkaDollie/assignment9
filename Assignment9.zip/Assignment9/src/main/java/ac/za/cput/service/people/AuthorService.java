package ac.za.cput.service.people;

import ac.za.cput.domain.people.Author;
import ac.za.cput.service.IService;

import java.util.Set;

public interface AuthorService extends IService<Author,String> {
    Set<Author> getAll();
}

