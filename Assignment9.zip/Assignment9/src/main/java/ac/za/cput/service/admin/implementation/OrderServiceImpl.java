package ac.za.cput.service.admin.implementation;

import ac.za.cput.domain.admin.Order;
import ac.za.cput.repository.admin.OrderRepository;
import ac.za.cput.repository.admin.implementation.OrderRepositoryImpl;
import ac.za.cput.service.admin.OrderService;

import java.util.Set;

public class OrderServiceImpl implements OrderService {

    private static OrderServiceImpl service = null;
    private OrderRepository repository;

    private OrderServiceImpl() {
        this.repository = OrderRepositoryImpl.getRepository();
    }

    public static OrderServiceImpl getService(){
        if (service == null) service = new OrderServiceImpl();
        return service;
    }




    @Override
    public Set<Order> getAll() {
        return this.repository.getAll();
    }

    @Override
    public Order create(Order order) {
        return this.repository.create(order);
    }

    @Override
    public Order update(Order order) {
        return this.repository.update(order);
    }

    @Override
    public void delete(String s) {
         this.repository.delete(s);
    }

    @Override
    public Order read(String s) {
        return this.repository.read(s);
    }
}
