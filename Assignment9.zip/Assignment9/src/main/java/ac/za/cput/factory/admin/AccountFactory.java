package ac.za.cput.factory.admin;

import ac.za.cput.domain.admin.Account;

public class AccountFactory {


    public static Account getAccount(String id, String holderName) {
        return new Account.Builder().id(id)
                .holderName(holderName)
                .build();
    }
}
