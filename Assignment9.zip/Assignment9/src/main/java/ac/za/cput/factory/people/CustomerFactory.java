package ac.za.cput.factory.people;

import ac.za.cput.domain.people.Customer;

public class CustomerFactory {



    public static Customer getCustomer(String id,String firstName, String lastName, int age, String email, String phoneNumber) {
        return new Customer.Builder().id(id)
                 .age(age)
                .firstName(firstName)
                .lastName(lastName)
                .email(email)
                .phoneNumber(phoneNumber)
                .build();
    }

}
