package ac.za.cput.service.admin.implementation;

import ac.za.cput.domain.admin.Address;
import ac.za.cput.repository.admin.AddressRepository;
import ac.za.cput.repository.admin.implementation.AddressRepositoryImpl;
import ac.za.cput.service.admin.AddressService;

import java.util.List;

public class AddressServiceImpl implements AddressService {

    private static AddressServiceImpl service = null;
    private AddressRepository repository;

    private AddressServiceImpl() {
        this.repository = AddressRepositoryImpl.getRepository();
    }

    public static AddressServiceImpl getService(){
        if (service == null) service = new AddressServiceImpl();
        return service;
    }



    @Override
    public List<Address> getAll() {
        return this.repository.getAll();
    }

    @Override
    public Address create(Address address) {
        return this.repository.create(address);
    }

    @Override
    public Address update(Address address) {
        return this.repository.update(address);
    }

    @Override
    public void delete(String s) {
        this.repository.delete(s);
    }

    @Override
    public Address read(String s) {
        return this.repository.read(s);
    }
}
