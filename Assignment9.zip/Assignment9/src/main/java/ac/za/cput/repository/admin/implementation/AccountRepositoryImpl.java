package ac.za.cput.repository.admin.implementation;

import ac.za.cput.domain.admin.Account;
import ac.za.cput.repository.admin.AccountRepository;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;


public class AccountRepositoryImpl implements AccountRepository {



    private static AccountRepositoryImpl repository = null;
    private Set<Account> account;

    private AccountRepositoryImpl (){
        this.account = new HashSet<>();
    }

    private Account findAccount(final String accountID) {
        return this.account.stream()
                .filter(account ->account.getID().trim().equals(accountID))
                .findAny()
                .orElse(null);
    }

    public static AccountRepositoryImpl getRepository(){
        if (repository == null) repository = new AccountRepositoryImpl();
        return repository;
    }


    @Override
    public Set<Account> getAll() {
        return account;
    }

    @Override
    public Account create(Account account) {
        this.account.add(account);


        return account;
    }

    @Override
    public Account update(Account accountt) {
        Account toDelete = findAccount(accountt.getID());
        if(toDelete != null) {
            this.account.remove(toDelete);
            return create(accountt);
        }
        return null;
    }

    @Override
    public void delete(String s) {

       Account account = findAccount(s);
        if (account != null) this.account.remove(account);
    }

    @Override
    public Account read(String s) {

        Account account = findAccount(s);
        return account;
    }
}
