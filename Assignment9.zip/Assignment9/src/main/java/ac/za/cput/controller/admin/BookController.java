package ac.za.cput.controller.admin;

import ac.za.cput.domain.admin.Book;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.*;
import ac.za.cput.service.admin.BookService;

import java.util.Set;

@RestController
@RequestMapping("/book")
public class BookController {

    @Autowired
    @Qualifier("ServiceImpl")
    private BookService service;

    @PostMapping("/create")
    @ResponseBody
    public Book create(Book book) {
        return service.create(book);
    }

    @PostMapping("/update")
    @ResponseBody
    public Book update(Book book) {
        return service.update(book);
    }

    @GetMapping("/delete/{id}")
    @ResponseBody
    public void delete(@PathVariable String id) {
        service.delete(id);

    }

    @GetMapping("/read/{id}")
    @ResponseBody
    public Book read(@PathVariable String id) {
        return service.read(id);
    }

    @GetMapping("/read/all")
    @ResponseBody
    public Set<Book> getAll() {
        return service.getAll();
    }
}
