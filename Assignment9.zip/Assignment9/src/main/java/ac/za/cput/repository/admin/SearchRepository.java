package ac.za.cput.repository.admin;

import ac.za.cput.domain.admin.Search;
import ac.za.cput.repository.IRepository;

import java.util.List;

public interface SearchRepository extends IRepository<Search,String> {
    List<Search> getAll();
}
