package ac.za.cput.repository.people.implementation;

import ac.za.cput.domain.people.Administrator;
import ac.za.cput.repository.people.AdministratorRepository;

import java.util.HashSet;
import java.util.Set;

public class AdministratorRepositoryImpl implements AdministratorRepository {


    private static AdministratorRepositoryImpl repository = null;
    private Set<Administrator> administrators;

    private AdministratorRepositoryImpl (){
        this.administrators = new HashSet<>();
    }

    private Administrator findAdministrator(final String adminustratorID) {
        return this.administrators.stream()
                .filter(administrator ->administrator.getID().trim().equals(adminustratorID))
                .findAny()
                .orElse(null);
    }

    public static AdministratorRepositoryImpl getRepository() {
        if (repository == null) repository = new AdministratorRepositoryImpl();
        return repository;
    }

    @Override
    public Set<Administrator> getAll() {
        return administrators;
    }

    @Override
    public Administrator create(Administrator administrator) {
        this.administrators.add(administrator);
        return administrator;
    }

    @Override
    public Administrator update(Administrator administrator) {
        Administrator toDelete = findAdministrator(administrator.getID());
        if(toDelete != null) {
            this.administrators.remove(toDelete);
            return create(administrator);
        }
        return null;
    }

    @Override
    public void delete(String s) {
        Administrator administrator= findAdministrator(s);
        if (administrator != null) this.administrators.remove(administrator);
    }

    @Override
    public Administrator read(String s) {
        Administrator administrator= findAdministrator(s);
        return administrator;
    }
}
