package ac.za.cput.repository.admin;

import ac.za.cput.repository.IRepository;

import java.util.Set;

public interface OrderStatus extends IRepository<OrderStatus,String> {
    Set<OrderStatus> getAll();
}
