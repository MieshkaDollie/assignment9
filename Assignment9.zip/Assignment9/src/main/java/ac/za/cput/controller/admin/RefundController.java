package ac.za.cput.controller.admin;

import ac.za.cput.domain.admin.Refund;
import ac.za.cput.service.admin.RefundService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.*;

import java.util.Set;

@RestController
@RequestMapping("/refund")
public class RefundController {

    @Autowired
    @Qualifier("ServiceImpl")
    private RefundService service;

    @PostMapping("/create")
    @ResponseBody
    public Refund create(Refund refund) {
        return service.create(refund);
    }

    @PostMapping("/update")
    @ResponseBody
    public Refund update(Refund refund ) {
        return service.update(refund);
    }

    @GetMapping("/delete/{id}")
    @ResponseBody
    public void delete(@PathVariable String id) {
        service.delete(id);

    }

    @GetMapping("/read/{id}")
    @ResponseBody
    public Refund read(@PathVariable String id) {
        return service.read(id);
    }

    @GetMapping("/read/all")
    @ResponseBody
    public Set<Refund> getAll() {
        return service.getAll();
    }
}
