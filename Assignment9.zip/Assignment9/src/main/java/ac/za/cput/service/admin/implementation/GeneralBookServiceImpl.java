package ac.za.cput.service.admin.implementation;

import ac.za.cput.domain.admin.GeneralBook;
import ac.za.cput.repository.admin.GeneralBookRepository;
import ac.za.cput.repository.admin.implementation.GeneralBookRepositoryImpl;
import ac.za.cput.service.admin.GeneralBookService;

import java.util.Set;

public class GeneralBookServiceImpl implements GeneralBookService {

    private static  GeneralBookServiceImpl service = null;
    private GeneralBookRepository repository;

    private GeneralBookServiceImpl() {
        this.repository = GeneralBookRepositoryImpl.getRepository();
    }

    public static GeneralBookServiceImpl getService(){
        if (service == null) service = new GeneralBookServiceImpl();
        return service;
    }



    @Override
    public Set<GeneralBook> getAll() {
        return this.repository.getAll();
    }

    @Override
    public GeneralBook create(GeneralBook generalBook) {
        return this.repository.create(generalBook);
    }

    @Override
    public GeneralBook update(GeneralBook generalBook) {
        return this.update(generalBook);
    }

    @Override
    public void delete(String s) {
       this.repository.delete(s);
    }

    @Override
    public GeneralBook read(String s) {
        return this.repository.read(s);
    }
}
