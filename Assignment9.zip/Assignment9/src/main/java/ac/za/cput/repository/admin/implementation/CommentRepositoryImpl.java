package ac.za.cput.repository.admin.implementation;

import ac.za.cput.domain.admin.Comment;
import ac.za.cput.repository.admin.CommentRepository;

import java.util.HashSet;
import java.util.Set;

public class CommentRepositoryImpl implements CommentRepository {




    private static CommentRepositoryImpl repository = null;
    private Set<Comment> comment;

    private CommentRepositoryImpl (){
        this.comment = new HashSet<>();
    }

    private Comment findComment(final String commentID) {
        return this.comment.stream()
                .filter(comment ->comment.getcommentId().trim().equals(commentID))
                .findAny()
                .orElse(null);
    }

    public static CommentRepositoryImpl getRepository(){
        if (repository == null) repository = new CommentRepositoryImpl();
        return repository;
    }

    @Override
    public Set<Comment> getAll() {
        return this.comment;
    }

    @Override
    public Comment create(Comment comment) {

        this.comment.add(comment);

        return comment;
    }

    @Override
    public Comment update(Comment comment) {

        Comment toDelete = findComment(comment.getcommentId());
        if(toDelete != null) {
            this.comment.remove(toDelete);
            return create(comment);
        }
        return null;
    }

    @Override
    public void delete(String s) {
        Comment comment= findComment(s);
        if (comment != null) this.comment.remove(comment);
    }

    @Override
    public Comment read(String s) {

        Comment comment=findComment(s);
        return comment;
    }
}
