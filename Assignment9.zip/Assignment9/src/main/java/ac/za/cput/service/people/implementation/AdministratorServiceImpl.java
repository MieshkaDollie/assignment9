package ac.za.cput.service.people.implementation;

import ac.za.cput.domain.people.Administrator;
import ac.za.cput.repository.people.AdministratorRepository;
import ac.za.cput.repository.people.implementation.AdministratorRepositoryImpl;
import ac.za.cput.service.people.AdministratorService;

import java.util.Set;

public class AdministratorServiceImpl implements AdministratorService {

    private static AdministratorServiceImpl service = null;
    private AdministratorRepository repository;

    private AdministratorServiceImpl() {
        this.repository = AdministratorRepositoryImpl.getRepository();
    }

    public static AdministratorServiceImpl getService(){
        if (service == null) service = new AdministratorServiceImpl();
        return service;
    }



    @Override
    public Set<Administrator> getAll() {
        return this.repository.getAll();
    }

    @Override
    public Administrator create(Administrator administrator) {
        return this.repository.create(administrator);
    }

    @Override
    public Administrator update(Administrator administrator) {
        return this.repository.update(administrator);
    }

    @Override
    public void delete(String s) {
    this.repository.delete(s);
    }

    @Override
    public Administrator read(String s) {
        return this.repository.read(s);
    }
}
