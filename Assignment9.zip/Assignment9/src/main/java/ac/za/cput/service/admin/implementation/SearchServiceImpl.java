package ac.za.cput.service.admin.implementation;

import ac.za.cput.domain.admin.Search;
import ac.za.cput.service.admin.SearchService;

import java.util.Set;

public class SearchServiceImpl implements SearchService {
    @Override
    public Set<Search> getAll() {
        return null;
    }

    @Override
    public Search create(Search search) {
        return null;
    }

    @Override
    public Search update(Search search) {
        return null;
    }

    @Override
    public void delete(String s) {

    }

    @Override
    public Search read(String s) {
        return null;
    }
}
