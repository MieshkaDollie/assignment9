package ac.za.cput.repository.admin;

import ac.za.cput.domain.admin.Review;
import ac.za.cput.repository.IRepository;

import java.util.Set;

public interface ReviewRepository extends IRepository<Review,String> {
    Set<Review> getAll();
}
