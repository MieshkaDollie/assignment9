package ac.za.cput.repository.admin.implementation;

import ac.za.cput.domain.admin.Coupon;
import ac.za.cput.repository.admin.CouponRepository;

import java.util.HashSet;
import java.util.Set;

public class CouponRepositoryImpl implements CouponRepository {


    private static CouponRepositoryImpl repository = null;
    private Set<Coupon> coupon;

    private CouponRepositoryImpl (){
        this.coupon = new HashSet<>();
    }

    private Coupon findCoupon(final String couponID) {
        return this.coupon.stream()
                .filter(coupon ->coupon.getcouponId().trim().equals(couponID))
                .findAny()
                .orElse(null);
    }

    public static CouponRepositoryImpl getRepository(){
        if (repository == null) repository = new CouponRepositoryImpl();
        return repository;
    }

    @Override
    public Set<Coupon> getAll() {
        return this.coupon;
    }

    @Override
    public Coupon create(Coupon coupon) {
        this.coupon.add(coupon);

        return coupon;
    }

    @Override
    public Coupon update(Coupon coupon) {

        Coupon toDelete = findCoupon(coupon.getcouponId());
        if(toDelete != null) {
            this.coupon.remove(toDelete);
            return create(coupon);
        }
        return null;
    }

    @Override
    public void delete(String s) {
        Coupon coupon= findCoupon(s);
        if (coupon != null) this.coupon.remove(coupon);
    }

    @Override
    public Coupon read(String s) {
        Coupon coupon=findCoupon(s);
        return coupon;
    }
}
