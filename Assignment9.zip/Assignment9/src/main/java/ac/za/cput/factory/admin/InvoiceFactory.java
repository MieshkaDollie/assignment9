package ac.za.cput.factory.admin;

import ac.za.cput.domain.admin.Invoice;

public class InvoiceFactory {

    public static Invoice getInvoice(String number, double amount) {
        return new Invoice.Builder().number(number)
                .amount(amount)
                .build();
    }
}
