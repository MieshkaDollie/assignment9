package ac.za.cput.repository.people;

import ac.za.cput.domain.people.Author;
import ac.za.cput.factory.people.AuthorFactory;
import ac.za.cput.repository.people.AuthorRepository;
import ac.za.cput.repository.people.implementation.AuthorRepositoryImpl;
import org.junit.Assert;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

import java.util.Set;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class AuthorRepositoryImplementationTest {

    private AuthorRepository repository;
    private Author author;

    private Author getSavedAuthor() {
        Set<Author> savedAuthors = this.repository.getAll();
        return savedAuthors.iterator().next();
    }

    @Before
    public void setUp() throws Exception {

        this.repository = AuthorRepositoryImpl.getRepository();
        this.author = AuthorFactory.getAuthor("James","Paul",22,"12345");
    }

    @Test
    public void a_create() {
        Author created = this.repository.create(this.author);
        System.out.println("In create, created = " + created);
        d_getAll();
        Assert.assertSame(created, this.author);
    }

    @Test
    public void b_read() {
        Author savedAuthor = getSavedAuthor();
        System.out.println("In read, AuthorBio = "+ savedAuthor.getBio());
        Author read = this.repository.read(savedAuthor.getBio());
        System.out.println("In read, read = " + read);
        d_getAll();
        Assert.assertEquals(savedAuthor, read);
    }

    @Test
    public void e_delete() {
        Author savedAuthor = getSavedAuthor();
        this.repository.delete(savedAuthor.getBio());
        //d_getAll();
        System.out.println( "Author deleted" );
        Assert.assertEquals(0,repository.getAll().size());
    }

    @Test
    public void d_getAll() {
        Set<Author> all = this.repository.getAll();
        System.out.println("In getAll, all = " + all);
        Assert.assertSame(1, all.size());
    }

    @Test
    public void c_update() {
        String newfname = "Alves";
        Author author = new Author.Builder().copy(getSavedAuthor()).firstName(newfname).build();
        System.out.println("In update, about_to_updated = " + author);
        Author updated = this.repository.update(author);
        System.out.println("In update, updated = " + updated);
        Assert.assertSame(newfname, updated.getFirsName());
        d_getAll();
    }
}
