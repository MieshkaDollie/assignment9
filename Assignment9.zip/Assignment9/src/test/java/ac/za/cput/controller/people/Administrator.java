package ac.za.cput.controller.people;

public class Administrator {
}
