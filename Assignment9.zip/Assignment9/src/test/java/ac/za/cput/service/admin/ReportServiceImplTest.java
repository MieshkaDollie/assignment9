package ac.za.cput.service.admin;

import ac.za.cput.domain.admin.Report;
import ac.za.cput.factory.admin.ReportFactory;
import ac.za.cput.repository.admin.ReportRepository;
import ac.za.cput.repository.admin.implementation.ReportRepositoryImpl;
import org.junit.Assert;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

import java.util.Set;
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class ReportServiceImplTest {


    private ReportRepository repository;
    private Report report ;

    private Report getSavedReport() {
        Set<Report> savedReports = this.repository.getAll();
        return savedReports.iterator().next();
    }

    @Before
    public void setUp() throws Exception {

        this.repository = ReportRepositoryImpl.getRepository();
        this.report= ReportFactory.getReport("1234","12/11/2018","Jordan peterson",3254);
    }

    @Test
    public void a_create() {
        Report created = this.repository.create(this.report);
        System.out.println("In create, created = " + created);
        d_getAll();
        Assert.assertSame(created, this.report);
    }

    @Test
    public void b_read() {
        Report savedReport = getSavedReport();
        System.out.println("In read, ReportId = "+ savedReport.getReportID());
        Report read = this.repository.read(savedReport.getReportID());
        System.out.println("In read, read = " + read);
        d_getAll();
        Assert.assertEquals(savedReport, read);
    }


    @Test
    public void e_delete() {
        Report savedReport = getSavedReport();
        this.repository.delete(savedReport.getReportID());
        //d_getAll();
        System.out.println( "Reoirt deleted" );
        Assert.assertEquals(0,repository.getAll().size());
    }

    @Test
    public void d_getAll() {
        Set<Report> all = this.repository.getAll();
        System.out.println("In getAll, all = " + all);
        Assert.assertSame(1, all.size());
    }

    @Test
    public void c_update() {
        String newdesc = "7 rules";
        Report report = new Report.Builder().copy(getSavedReport()).description(newdesc).build();
        System.out.println("In update, about_to_updated = " + report);
        Report updated = this.repository.update(report);
        System.out.println("In update, updated = " + report);
        Assert.assertSame(newdesc, updated.getDescription());
        d_getAll();
    }
}
