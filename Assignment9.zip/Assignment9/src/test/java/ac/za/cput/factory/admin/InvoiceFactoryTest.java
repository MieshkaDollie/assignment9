package ac.za.cput.factory.admin;

import ac.za.cput.domain.admin.Invoice;
import ac.za.cput.factory.admin.InvoiceFactory;
import org.junit.Assert;
import org.junit.Test;

public class InvoiceFactoryTest {

    @Test
    public void getInvoice() {

        String number="12";

        double amount=2000;



        Invoice invoice = InvoiceFactory.getInvoice(number,amount);
        System.out.println(invoice);
        Assert.assertEquals("12", invoice.getNumber());
    }
}
