package ac.za.cput.service.admin;

import ac.za.cput.domain.admin.GeneralBook;
import ac.za.cput.factory.admin.GeneralBookFactory;
import ac.za.cput.repository.admin.GeneralBookRepository;
import ac.za.cput.repository.admin.implementation.GeneralBookRepositoryImpl;
import org.junit.Assert;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

import java.util.Set;
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class GeneralBookServiceImplTest {
    private GeneralBookRepository repository;
    private GeneralBook generalBook;

    private GeneralBook getSavedGeneralBook() {
        Set<GeneralBook> savedGeneralBooks = this.repository.getAll();
        return savedGeneralBooks.iterator().next();
    }


    @Before
    public void setUp() throws Exception {

        this.repository = GeneralBookRepositoryImpl.getRepository();
        this.generalBook = GeneralBookFactory.getGeneralBook("1234","Mr Fool");
    }

    @Test
    public void a_create() {
        GeneralBook created = this.repository.create(this.generalBook);
        System.out.println("In create, created = " + created);
        d_getAll();
        Assert.assertSame(created, this.generalBook);
    }

    @Test
    public void b_read() {
        GeneralBook savedGeneralBook = getSavedGeneralBook();
        System.out.println("In read, BookId = "+ savedGeneralBook.getBookId());
        GeneralBook read = this.repository.read(savedGeneralBook.getBookId());
        System.out.println("In read, read = " + read);
        d_getAll();
        Assert.assertEquals(savedGeneralBook, read);
    }

    @Test
    public void e_delete() {
        GeneralBook savedGeneralBook = getSavedGeneralBook();
        this.repository.delete(savedGeneralBook.getBookId());
        //d_getAll();
        System.out.println( "Book deleted" );
        Assert.assertEquals(0,repository.getAll().size());
    }

    @Test
    public void d_getAll() {
        Set<GeneralBook> all = this.repository.getAll();
        System.out.println("In getAll, all = " + all);
        Assert.assertSame(1, all.size());
    }

    @Test
    public void c_update() {
        String newtitle = "100 rules";
        GeneralBook generalBook = new GeneralBook.Builder().copy(getSavedGeneralBook()).title(newtitle).build();
        System.out.println("In update, about_to_updated = " +generalBook);
        GeneralBook updated = this.repository.update(generalBook);
        System.out.println("In update, updated = " + generalBook);
        Assert.assertSame(newtitle, updated.getTitle());
        d_getAll();
    }
}
