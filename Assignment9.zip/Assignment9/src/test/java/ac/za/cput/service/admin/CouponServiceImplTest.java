package ac.za.cput.service.admin;

import ac.za.cput.domain.admin.Coupon;
import ac.za.cput.factory.admin.CouponFactory;
import ac.za.cput.repository.admin.CouponRepository;
import ac.za.cput.repository.admin.implementation.CouponRepositoryImpl;
import org.junit.Assert;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

import java.util.Set;
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class CouponServiceImplTest {

    private CouponRepository repository;
    private Coupon coupon;

    private Coupon getSavedCoupon() {
        Set<Coupon> savedCoupons = this.repository.getAll();
        return savedCoupons.iterator().next();
    }

    @Before
    public void setUp() throws Exception {

        this.repository = CouponRepositoryImpl.getRepository();
        this.coupon = CouponFactory.getCoupon("1234","10/12/2018","11/11/2019");
    }

    @Test
    public void a_create() {
        Coupon  created = this.repository.create(this.coupon);
        System.out.println("In create, created = " + created);
        d_getAll();
        Assert.assertSame(created, this.coupon);
    }

    @Test
    public void b_read() {
        Coupon  savedCoupon = getSavedCoupon();
        System.out.println("In read, BookId = "+ savedCoupon.getcouponId());
        Coupon read = this.repository.read(savedCoupon.getcouponId());
        System.out.println("In read, read = " + read);
        d_getAll();
        Assert.assertEquals(savedCoupon, read);


    }

    @Test
    public void e_delete() {
        Coupon savedCoupon = getSavedCoupon();
        this.repository.delete(savedCoupon.getcouponId());
        //d_getAll();
        System.out.println( "Coupon deleted" );
        Assert.assertEquals(0,repository.getAll().size());
    }

    @Test
    public void d_getAll() {
        Set<Coupon> all = this.repository.getAll();
        System.out.println("In getAll, all = " + all);
        Assert.assertSame(1, all.size());
    }

    @Test
    public void c_update() {
        String newdeff = "1/1/2019";
        Coupon coupon = new Coupon.Builder().copy(getSavedCoupon()).dateEff(newdeff).build();
        System.out.println("In update, about_to_updated = " + coupon);
        Coupon updated = this.repository.update(coupon);
        System.out.println("In update, updated = " + coupon);
        Assert.assertSame(newdeff, updated.getdateEff());
        d_getAll();
    }

}
