package ac.za.cput.factory.admin;

import ac.za.cput.domain.admin.Order;
import ac.za.cput.factory.admin.OrderFactory;
import org.junit.Assert;
import org.junit.Test;

public class OrderFactoryTest {

    @Test
    public void getOrder() {

        String orderNum="12";
        String custId="C3754";
        double amount=2000;
        String description="Book: 12 Rules for life";


        Order order = OrderFactory.getOrder(orderNum,custId,amount,description);
        System.out.println(order);
        Assert.assertEquals(12, order.getOrderNumber());
    }
}
