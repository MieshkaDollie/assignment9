package ac.za.cput.factory.admin;

import ac.za.cput.domain.admin.Comment;
import ac.za.cput.factory.admin.CommentFactory;
import org.junit.Assert;
import org.junit.Test;

public class CommentFactoryTest {



    @Test
    public void getComment() {

        String commentId="MD1325532";
        String customerId = "C2833";
        String bookId = "565tf";


        Comment comment =  CommentFactory.getComment(commentId,bookId,customerId);
        System.out.println(comment);
        Assert.assertEquals("MD1325532", comment.getcommentId());
    }
}
