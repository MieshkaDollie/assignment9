package ac.za.cput.controller.admin;

import ac.za.cput.domain.admin.Book;
import ac.za.cput.factory.admin.BookFactory;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.*;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.client.HttpClientErrorException;

import static junit.framework.TestCase.assertEquals;
import static junit.framework.TestCase.assertNotNull;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@RunWith(SpringRunner.class)
public class BookControllerTest {

    @Autowired
    private TestRestTemplate restTemplate;
    private String baseURL="http://localhost:8080/book";

    @Test
    public void testGetAllBooks() {
        HttpHeaders headers = new HttpHeaders();
        HttpEntity<String> entity = new HttpEntity<String>(null, headers);
        ResponseEntity<String> response = restTemplate.exchange(baseURL + "/all",
                HttpMethod.GET, entity, String.class);
        assertNotNull(response.getBody());
    }


    @Ignore
    public void testGetBookById() {
        Book book = restTemplate.getForObject(baseURL + "/book/1", Book.class);
        System.out.println(book.getAuthor());
        assertNotNull(book);
    }

    @Ignore
    public void testCreateStudent() {
        Book book = BookFactory.getBook("1"," 12 rules of life","Jordan Peterson","Pscy","1st","12/2/1999","assd");

        ResponseEntity<Book> postResponse = restTemplate.postForEntity(baseURL + "/create", book, Book.class);
        assertNotNull(postResponse);
        assertNotNull(postResponse.getBody());
    }

    @Ignore
    public void testUpdateStudent() {
        String id = "1";
        Book book = restTemplate.getForObject(baseURL + "/book/" + id, Book.class);

        restTemplate.put(baseURL + "/books/" + id, book);
        Book updatedBook = restTemplate.getForObject(baseURL + "/Book/" + id, Book.class);
        assertNotNull(updatedBook);
    }

    @Ignore
    public void testDeleteEmployee() {
        String id ="2";
        Book book = restTemplate.getForObject(baseURL + "/books/" + id, Book.class);
        assertNotNull(book);
        restTemplate.delete(baseURL + "/books/" + id);
        try {
            book = restTemplate.getForObject(baseURL + "/books/" + id, Book.class);
        } catch (final HttpClientErrorException e) {
            assertEquals(e.getStatusCode(), HttpStatus.NOT_FOUND);
        }
    }
}
