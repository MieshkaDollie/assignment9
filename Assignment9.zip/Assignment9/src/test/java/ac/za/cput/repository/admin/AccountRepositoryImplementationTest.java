package ac.za.cput.repository.admin;

import ac.za.cput.domain.admin.Account;
import ac.za.cput.factory.admin.AccountFactory;
import ac.za.cput.factory.admin.BookFactory;
import ac.za.cput.repository.admin.AccountRepository;
import ac.za.cput.repository.admin.implementation.AccountRepositoryImpl;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.util.Set;

public class AccountRepositoryImplementationTest {

    private AccountRepository repository;
    private Account account;

    private Account getSavedAccount() {
        Set<Account> savedAccounts = this.repository.getAll();
        return savedAccounts.iterator().next();
    }

    @Before
    public void setUp() throws Exception {

        this.repository = AccountRepositoryImpl.getRepository();
        this.account = AccountFactory.getAccount("11r4r","John Stones");
    }

    @Test
    public void a_create() {
        Account created = this.repository.create(this.account);
        System.out.println("In create, created = " + created);
        d_getAll();
        Assert.assertSame(created, this.account);
    }

    @Test
    public void b_read() {
        Account savedAccount = getSavedAccount();
        System.out.println("In read, BookId = "+ savedAccount.getID());
        Account read = this.repository.read(savedAccount.getID());
        System.out.println("In read, read = " + read);
        d_getAll();
        Assert.assertEquals(savedAccount, read);
    }

    @Test
    public void e_delete() {
        Account savedAccount = getSavedAccount();
        this.repository.delete(savedAccount.getID());
        //d_getAll();
        System.out.println( "Book deleted" );
        Assert.assertEquals(0,repository.getAll().size());
    }

    @Test
    public void d_getAll() {
        Set<Account> all = this.repository.getAll();
        System.out.println("In getAll, all = " + all);
        Assert.assertSame(1, all.size());
    }

    @Test
    public void c_update() {
        String newname = "7 rules";
        Account account = new Account.Builder().copy(getSavedAccount()).holderName(newname).build();
        System.out.println("In update, about_to_updated = " + account);
        Account updated = this.repository.update(account);
        System.out.println("In update, updated = " + account);
        Assert.assertSame(newname, updated.getHolderName());
        d_getAll();
    }
}
