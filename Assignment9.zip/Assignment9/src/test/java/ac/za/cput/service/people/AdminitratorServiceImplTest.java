package ac.za.cput.service.people;

import ac.za.cput.domain.people.Administrator;
import ac.za.cput.factory.people.AdministratorFactory;
import ac.za.cput.repository.people.AdministratorRepository;
import ac.za.cput.repository.people.implementation.AdministratorRepositoryImpl;
import org.junit.Assert;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

import java.util.Set;
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class AdminitratorServiceImplTest {
    private AdministratorRepository repository;
    private Administrator administrator;

    private Administrator getSavedAdministrator() {
        Set<Administrator> savedAdministrators = this.repository.getAll();
        return savedAdministrators.iterator().next();
    }

    @Before
    public void setUp() throws Exception {

        this.repository = AdministratorRepositoryImpl.getRepository();
        this.administrator = AdministratorFactory.getAdministrator("1234","Paul","Jeterson");
    }

    @Test
    public void a_create() {
        Administrator created = this.repository.create(this.administrator);
        System.out.println("In create, created = " + created);
        d_getAll();
        Assert.assertSame(created, this.administrator);
    }

    @Test
    public void b_read() {
        Administrator savedAdministrator = getSavedAdministrator();
        System.out.println("In read, BookId = "+ savedAdministrator.getID());
        Administrator read = this.repository.read(savedAdministrator.getID());
        System.out.println("In read, read = " + read);
        d_getAll();
        Assert.assertEquals(savedAdministrator, read);
    }

    @Test
    public void e_delete() {
        Administrator savedAdministrator = getSavedAdministrator();
        this.repository.delete(savedAdministrator.getID());
        //d_getAll();
        System.out.println( "Administrator deleted" );
        Assert.assertEquals(0,repository.getAll().size());
    }

    @Test
    public void d_getAll() {
        Set<Administrator> all = this.repository.getAll();
        System.out.println("In getAll, all = " + all);
        Assert.assertSame(1, all.size());
    }

    @Test
    public void c_update() {
        String newfname = "Alves";
        Administrator administrator = new Administrator.Builder().copy(getSavedAdministrator()).fName(newfname).build();
        System.out.println("In update, about_to_updated = " + administrator);
        Administrator updated = this.repository.update(administrator);
        System.out.println("In update, updated = " + administrator);
        Assert.assertSame(newfname, updated.getFName());
        d_getAll();
    }
}
