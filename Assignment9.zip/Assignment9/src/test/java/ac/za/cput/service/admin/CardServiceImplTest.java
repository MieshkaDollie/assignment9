package ac.za.cput.service.admin;

import ac.za.cput.domain.admin.Card;
import ac.za.cput.factory.admin.CardFactory;
import ac.za.cput.repository.admin.CardRepository;
import ac.za.cput.repository.admin.implementation.CardRepositoryImpl;
import org.junit.Assert;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

import java.util.Set;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class CardServiceImplTest {


    private CardRepository repository;
    private Card card;

    private Card getSavedCard() {
        Set<Card> savedCards = this.repository.getAll();
        return savedCards.iterator().next();
    }

    @Before
    public void setUp() throws Exception {

        this.repository = CardRepositoryImpl.getRepository();
        this.card = CardFactory.getCard("12343556364","John Stones","FNB");
    }

    @Test
    public void a_create() {
        Card created = this.repository.create(this.card);
        System.out.println("In create, created = " + created);
        d_getAll();
        Assert.assertNotNull(created);
        Assert.assertSame(created, this.card);
    }

    @Test
    public void b_read() {
        Card savedCard = getSavedCard();
        System.out.println("In read, BookId = "+ savedCard.getCardNumber());
        Card read = this.repository.read(savedCard.getCardNumber());
        System.out.println("In read, read = " + read);
        d_getAll();
        Assert.assertEquals(savedCard, read);
    }

    @Test
    public void e_delete() {
        Card savedCard = getSavedCard();
        this.repository.delete(savedCard.getCardNumber());
        //d_getAll();
        System.out.println( "Card deleted" );
        Assert.assertEquals(0,repository.getAll().size());
    }

    @Test
    public void d_getAll() {
        Set<Card> all = this.repository.getAll();
        System.out.println("In getAll, all = " + all);
        Assert.assertSame(1, all.size());
    }

    @Test
    public void c_update() {
        String newholdername = "Arthur";
        Card card = new Card.Builder().copy(getSavedCard()).cardOwner(newholdername).build();
        System.out.println("In update, about_to_updated = " + card);
        Card updated = this.repository.update(card);
        System.out.println("In update, updated = " + card);
        Assert.assertSame(newholdername, updated.getCardOwner());
        d_getAll();
    }


}
