package ac.za.cput.service.admin;

import ac.za.cput.domain.admin.ReferenceBook;
import ac.za.cput.factory.admin.ReferenceBookFactory;
import ac.za.cput.repository.admin.ReferenceBookRepository;
import ac.za.cput.repository.admin.implementation.ReferenceBookRepositoryImpl;
import org.junit.Assert;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

import java.util.Set;
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class ReferenceBookServiceImplTest {

    private ReferenceBookRepository repository;
    private ReferenceBook referenceBook;

    private ReferenceBook getSavedReferenceBook() {
        Set<ReferenceBook> savedReferenceBooks = this.repository.getAll();
        return savedReferenceBooks.iterator().next();
    }

    @Before
    public void setUp() throws Exception {

        this.repository = ReferenceBookRepositoryImpl.getRepository();
        this.referenceBook = ReferenceBookFactory.getReferenceBook("1234","12 Rules for life");
    }

    @Test
    public void a_create() {
        ReferenceBook created = this.repository.create(this.referenceBook);
        System.out.println("In create, created = " + created);
        d_getAll();
        Assert.assertSame(created, this.referenceBook);
    }

    @Test
    public void b_read() {
        ReferenceBook savedReferenceBook = getSavedReferenceBook();
        System.out.println("In read, BookId = "+ savedReferenceBook.getBookId());
        ReferenceBook read = this.repository.read(savedReferenceBook.getBookId());
        System.out.println("In read, read = " + read);
        d_getAll();
        Assert.assertEquals(savedReferenceBook, read);
    }

    @Test
    public void e_delete() {
        ReferenceBook savedReferenceBook = getSavedReferenceBook();
        this.repository.delete(savedReferenceBook.getBookId());
        //d_getAll();
        System.out.println( "Book deleted" );
        Assert.assertEquals(0,repository.getAll().size());
    }

    @Test
    public void d_getAll() {
        Set<ReferenceBook> all = this.repository.getAll();
        System.out.println("In getAll, all = " + all);
        Assert.assertSame(1, all.size());
    }

    @Test
    public void c_update() {
        String newtitle = "7 rules";
        ReferenceBook referenceBook = new ReferenceBook.Builder().copy(getSavedReferenceBook()).title(newtitle).build();
        System.out.println("In update, about_to_updated = " + referenceBook);
        ReferenceBook updated = this.repository.update(referenceBook);
        System.out.println("In update, updated = " + referenceBook);
        Assert.assertSame(newtitle, updated.getTitle());
        d_getAll();
    }
}
