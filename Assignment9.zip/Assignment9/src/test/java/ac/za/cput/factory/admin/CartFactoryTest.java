package ac.za.cput.factory.admin;

import ac.za.cput.domain.admin.Cart;
import ac.za.cput.factory.admin.CartFactory;
import org.junit.Assert;
import org.junit.Test;

public class CartFactoryTest {

    @Test
    public void getCart() {

        String id="M3539";
        String category = "psychology";
        int amount=2;



        Cart cart =  CartFactory.getCart(id,"fhfh",amount,category);
        System.out.println(cart);
        Assert.assertEquals(2, cart.getAmount());
    }
}
