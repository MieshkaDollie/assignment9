package ac.za.cput.repository.admin;

import ac.za.cput.domain.admin.Invoice;
import ac.za.cput.factory.admin.InvoiceFactory;
import ac.za.cput.repository.admin.InvoiceRepository;
import ac.za.cput.repository.admin.implementation.InvoiceRepositoryImpl;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.util.Set;

public class OrderLineRepositoryImplementationTest {
    private InvoiceRepository repository;
    private Invoice invoice;

    private Invoice getSavedInvoice() {
        Set<Invoice> savedInvoices = this.repository.getAll();
        return savedInvoices.iterator().next();
    }
    @Before
    public void setUp() throws Exception {

        this.repository = InvoiceRepositoryImpl.getRepository();
        this.invoice = InvoiceFactory.getInvoice("1234",200);
    }

    @Test
    public void a_create() {
        Invoice created = this.repository.create(this.invoice);
        System.out.println("In create, created = " + created);
        d_getAll();
        Assert.assertSame(created, this.invoice);
    }


    @Test
    public void b_read() {
        Invoice savedInvoice = getSavedInvoice();
        System.out.println("In read, invoiceId = "+ savedInvoice.getNumber());
        Invoice read = this.repository.read(savedInvoice.getNumber());
        System.out.println("In read, read = " + read);
        d_getAll();
        Assert.assertEquals(savedInvoice, read);
    }

    @Test
    public void e_delete() {
        Invoice savedInvoice = getSavedInvoice();
        this.repository.delete(savedInvoice.getNumber());
        //d_getAll();
        System.out.println( "Invoice deleted" );
        Assert.assertEquals(0,repository.getAll().size());
    }

    @Test
    public void d_getAll() {
        Set<Invoice> all = this.repository.getAll();
        System.out.println("In getAll, all = " + all);
        Assert.assertSame(1, all.size());
    }

    @Test
    public void c_update() {
        int newam = 13;
        Invoice invoice = new Invoice.Builder().copy(getSavedInvoice()).amount(newam).build();
        System.out.println("In update, about_to_updated = " + invoice);
        Invoice updated = this.repository.update(invoice);
        System.out.println("In update, updated = " + invoice);
        Assert.assertSame(newam, updated.getAmount());
        d_getAll();
    }
}
