package ac.za.cput.factory.admin;

import ac.za.cput.domain.admin.CustomerStatus;
import ac.za.cput.factory.admin.CustomerStatusFactory;
import org.junit.Assert;
import org.junit.Test;

public class CustomerStatusFactoryTest {

    @Test
    public void getCustomerStatus(){

        String id="hdb6d";
        String status="blocked";

        CustomerStatus cs= CustomerStatusFactory.getCustomerStatus(id,status);
        System.out.println( cs);
        Assert.assertEquals("blocked",cs.getCustomerStatus());
    }
}
