package ac.za.cput.factory.people;

import ac.za.cput.domain.people.Administrator;
import ac.za.cput.factory.people.AdministratorFactory;
import org.junit.Assert;
import org.junit.Test;

public class AdministratorFactoryTest {



    @Test
    public void getAddress() {

        String id="ghg233";
        String fname="Jay";
        String sname="Costa";


        Administrator admin =  AdministratorFactory.getAdministrator(id,fname,sname);
        System.out.println(admin);
        Assert.assertEquals("Costa", admin.getSName());
    }
}
