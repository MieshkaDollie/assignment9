package ac.za.cput.factory.admin;

import ac.za.cput.domain.admin.GeneralBook;
import ac.za.cput.factory.admin.GeneralBookFactory;
import org.junit.Assert;
import org.junit.Test;

public class GeneralBookFactoryTest {

    @Test
    public void getGeneralBook(){

        String id="hdb6d";
        String title="circle";

       GeneralBook gb= GeneralBookFactory.getGeneralBook(id,title);
        System.out.println( gb);
        Assert.assertEquals("circle",gb.getTitle());
    }
}
