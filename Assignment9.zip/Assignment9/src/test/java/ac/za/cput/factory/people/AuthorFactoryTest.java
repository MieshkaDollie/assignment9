package ac.za.cput.factory.people;

import ac.za.cput.domain.people.Author;
import ac.za.cput.factory.people.AuthorFactory;
import org.junit.Assert;
import org.junit.Test;

public class AuthorFactoryTest {


    @Test
    public void getAuthor() {


        String fname="Jordan";
        String lname="Peterson";
        int age=45;
        String bio="hes from Canada...";


        Author author = AuthorFactory.getAuthor(fname,lname,age,bio);
        System.out.println(author);
        Assert.assertEquals("Jordan", author.getFirsName());
    }
}
