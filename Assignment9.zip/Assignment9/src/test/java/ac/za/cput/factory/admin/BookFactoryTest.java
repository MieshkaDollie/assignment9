package ac.za.cput.factory.admin;


import ac.za.cput.domain.admin.Book;
import ac.za.cput.factory.admin.BookFactory;
import org.junit.Assert;
import org.junit.Test;

public class BookFactoryTest {

    @Test
    public void getBook() {

        String id ="C367";
        String title = "12 Rules for life";
        String author = "Jordan Peterson";
        String category="Psychology";
        String edition="1st";
        String eddate = "12/4/2018";
       String desc="dkdhhkbhdnv";

        Book book= BookFactory.getBook(id,title,author,category,edition,eddate,desc);
        System.out.println(book);
        Assert.assertNotNull(book.getBookId());
    }
}
