package ac.za.cput.factory.admin;

import ac.za.cput.domain.admin.Coupon;
import ac.za.cput.factory.admin.CouponFactory;
import org.junit.Assert;
import org.junit.Test;

public class CouponFactoryTest {



    @Test
    public void getCoupon() {

        String couponId="MD1325532";
        String dateEff = "10/10/2013";
        String dateLoseEff = "10/10/2014";


        Coupon coupon =  CouponFactory.getCoupon(couponId,dateEff,dateLoseEff);
        System.out.println(coupon);
        Assert.assertEquals("MD1325532", coupon.getcouponId());
    }
}
