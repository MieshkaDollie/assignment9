package ac.za.cput.service.admin;

import ac.za.cput.domain.admin.CustomerStatus;
import ac.za.cput.factory.admin.CustomerStatusFactory;
import ac.za.cput.repository.admin.CustomerStatusRepository;
import ac.za.cput.repository.admin.implementation.CustomerStatusRepositoryImpl;
import org.junit.Assert;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

import java.util.Set;
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class CustomerStatusServiceImplTest {
    private CustomerStatusRepository repository;
    private CustomerStatus customerStatus;

    private CustomerStatus getSavedCustomerStatus() {
        Set<CustomerStatus> savedCustomerStatuses = this.repository.getAll();
        return savedCustomerStatuses.iterator().next();
    }

    @Before
    public void setUp() throws Exception {

        this.repository = CustomerStatusRepositoryImpl.getRepository();
        this.customerStatus = CustomerStatusFactory.getCustomerStatus("1234","blocked");
    }

    @Test
    public void a_create() {
        CustomerStatus created = this.repository.create(this.customerStatus);
        System.out.println("In create, created = " + created);
        d_getAll();
        Assert.assertSame(created, this.customerStatus);
    }

    @Test
    public void b_read() {
        CustomerStatus savedCustomerStatus = getSavedCustomerStatus();
        System.out.println("In read, customer id = "+ savedCustomerStatus.getCustomerId());
        CustomerStatus read = this.repository.read(savedCustomerStatus.getCustomerId());
        System.out.println("In read, read = " + read);
        d_getAll();
        Assert.assertEquals(savedCustomerStatus, read);
    }


    @Test
    public void e_delete() {
        CustomerStatus savedCustomerStatus = getSavedCustomerStatus();
        this.repository.delete(savedCustomerStatus.getCustomerId());
        //d_getAll();
        System.out.println( "Customer status deleted" );
        Assert.assertEquals(0,repository.getAll().size());
    }

    @Test
    public void d_getAll() {
        Set<CustomerStatus> all = this.repository.getAll();
        System.out.println("In getAll, all = " + all);
        Assert.assertSame(1, all.size());
    }

    @Test
    public void c_update() {
        String newstatus = "online";
        CustomerStatus customerStatus = new CustomerStatus.Builder().copy(getSavedCustomerStatus()).customerStatus(newstatus).build();
        System.out.println("In update, about_to_updated = " + customerStatus);
        CustomerStatus updated = this.repository.update(customerStatus);
        System.out.println("In update, updated = " + customerStatus);
        Assert.assertSame(newstatus, updated.getCustomerStatus());
        d_getAll();
    }


}
