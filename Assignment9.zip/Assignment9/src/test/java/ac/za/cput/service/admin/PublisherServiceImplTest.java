package ac.za.cput.service.admin;

import ac.za.cput.domain.admin.Publisher;
import ac.za.cput.factory.admin.PublisherFactory;
import ac.za.cput.repository.admin.PublisherRepository;
import ac.za.cput.repository.admin.implementation.PublisherRepositoryImpl;
import org.junit.Assert;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

import java.util.Set;
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class PublisherServiceImplTest {
    private PublisherRepository repository;
    private Publisher publisher;

    private Publisher getSavedPublisher() {
        Set<Publisher> savedPublishers = this.repository.getAll();
        return savedPublishers.iterator().next();
    }

    @Before
    public void setUp() throws Exception {

        this.repository = PublisherRepositoryImpl.getRepository();
        this.publisher = PublisherFactory.getPublisher("124534","Union Del Sul");
    }

    @Test
    public void a_create() {
        Publisher created = this.repository.create(this.publisher);
        System.out.println("In create, created = " + created);
        d_getAll();
        Assert.assertSame(created, this.publisher);
    }

    @Test
    public void b_read() {
        Publisher savedPublisher = getSavedPublisher();
        System.out.println("In read, Publishercode = "+ savedPublisher.getCode());
        Publisher read = this.repository.read(savedPublisher.getCode());
        System.out.println("In read, read = " + read);
        d_getAll();
        Assert.assertEquals(savedPublisher, read);
    }

    @Test
    public void e_delete() {
        Publisher savedPublisher = getSavedPublisher();
        this.repository.delete(savedPublisher.getCode());
        //d_getAll();
        System.out.println( "Publisher deleted" );
        Assert.assertEquals(0,repository.getAll().size());
    }

    @Test
    public void d_getAll() {
        Set<Publisher> all = this.repository.getAll();
        System.out.println("In getAll, all = " + all);
        Assert.assertSame(1, all.size());
    }

    @Test
    public void c_update() {
        String newdename = "Union Del Norte";
        Publisher publisher = new Publisher.Builder().copy(getSavedPublisher()).name(newdename).build();
        System.out.println("In update, about_to_updated = " + publisher);
        Publisher updated = this.repository.update(publisher);
        System.out.println("In update, updated = " + publisher);
        Assert.assertSame(newdename, updated.getName());
        d_getAll();
    }

}
