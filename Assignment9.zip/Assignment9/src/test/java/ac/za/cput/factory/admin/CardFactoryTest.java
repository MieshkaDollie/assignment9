package ac.za.cput.factory.admin;

import ac.za.cput.domain.admin.Card;
import ac.za.cput.factory.admin.CardFactory;
import org.junit.Assert;
import org.junit.Test;

public class CardFactoryTest {


    @Test
    public void getCard() {



        String number="123456789";
        String owner = "John Stones";
        String bank = "FNB";


        Card card =  CardFactory.getCard(number,owner,bank);
        System.out.println(card);
        Assert.assertEquals(123456789, card.getCardNumber());
    }
}
