package ac.za.cput.factory.admin;

import ac.za.cput.domain.admin.Account;
import ac.za.cput.factory.admin.AccountFactory;
import org.junit.Assert;
import org.junit.Test;

public class AccountFactoryTest {

    @Test
    public void getAccount(){


        String id="787hjj";
        String holdeername="Helder Costa";


        Account acc =  AccountFactory.getAccount(id,holdeername);
        System.out.println(acc);
        Assert.assertEquals("Helder Costa", acc.getHolderName());
    }
}
