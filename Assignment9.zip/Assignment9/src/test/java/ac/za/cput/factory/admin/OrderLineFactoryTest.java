package ac.za.cput.factory.admin;

import ac.za.cput.domain.admin.OrderLine;
import ac.za.cput.factory.admin.OrderLineFactory;
import org.junit.Assert;
import org.junit.Test;

public class OrderLineFactoryTest {

    @Test
    public void getOrderLine() {
        String orderNum="gfjehwgr7444";
        String bookid="12rer4";
        String desc="The guide";
        double amount=2000;



        OrderLine orderline = OrderLineFactory.getOrderLine(orderNum,bookid,amount,desc);
        System.out.println(orderline);
        Assert.assertEquals(2000, orderline.getAmount());
    }
}
