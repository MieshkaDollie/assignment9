package ac.za.cput.repository.admin;

import ac.za.cput.domain.admin.Comment;
import ac.za.cput.factory.admin.BookFactory;
import ac.za.cput.factory.admin.CommentFactory;
import ac.za.cput.repository.admin.CommentRepository;
import ac.za.cput.repository.admin.implementation.CommentRepositoryImpl;
import org.junit.Assert;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

import java.util.Set;
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class CommentRepositoryImplementationTest {

    private CommentRepository repository;
    private Comment comment;

    private Comment getSavedComment() {
        Set<Comment> savedComments = this.repository.getAll();
        return savedComments.iterator().next();
    }

    @Before
    public void setUp() throws Exception {

        this.repository = CommentRepositoryImpl.getRepository();
        this.comment = CommentFactory.getComment("1234","12g5","gdg45");
    }

    @Test
    public void a_create() {
            Comment created = this.repository.create(this.comment);
        System.out.println("In create, created = " + created);
        d_getAll();
        Assert.assertSame(created, this.comment);
    }

    @Test
    public void b_read() {
        Comment savedComment = getSavedComment();
        System.out.println("In read, CommentId = "+ savedComment.getcommentId());
        Comment read = this.repository.read(savedComment.getcommentId());
        System.out.println("In read, read = " + read);
        d_getAll();
        Assert.assertEquals(savedComment, read);
    }

    @Test
    public void e_delete() {
        Comment savedComment = getSavedComment();
        this.repository.delete(savedComment.getcommentId());
        //d_getAll();
        System.out.println( "Comment deleted" );
        Assert.assertEquals(0,repository.getAll().size());
    }

    @Test
    public void d_getAll() {
        Set<Comment> all = this.repository.getAll();
        System.out.println("In getAll, all = " + all);
        Assert.assertSame(1, all.size());
    }

    @Test
    public void c_update() {
        String newbook = "7777";
        Comment comment = new Comment.Builder().copy(getSavedComment()).bookId(newbook).build();
        System.out.println("In update, about_to_updated = " + comment);
        Comment updated = this.repository.update(comment);
        System.out.println("In update, updated = " + comment);
        Assert.assertSame(newbook, updated.getbookId());
        d_getAll();
    }
}
