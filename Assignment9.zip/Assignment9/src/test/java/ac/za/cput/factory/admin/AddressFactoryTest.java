package ac.za.cput.factory.admin;

import ac.za.cput.domain.admin.Address;
import ac.za.cput.factory.admin.AddressFactory;
import org.junit.Assert;
import org.junit.Test;

public class AddressFactoryTest {


    @Test
    public void getAddress() {

        String type="complex";
        String street = "5 Darling";
        String road="Three Anchor";
        String city="Cape Town";
        String country = "South Africa";


        Address address =  AddressFactory.getAddress(type,street,road,city,country);
        System.out.println(address);
        Assert.assertEquals("5 Darling", address.getStreet());
    }
}
