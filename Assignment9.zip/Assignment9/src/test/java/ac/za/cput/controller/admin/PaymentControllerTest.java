package ac.za.cput.controller.admin;

public class PaymentControllerTest {
}
