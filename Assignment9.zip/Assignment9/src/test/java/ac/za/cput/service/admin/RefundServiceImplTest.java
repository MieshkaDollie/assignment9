package ac.za.cput.service.admin;

import ac.za.cput.domain.admin.Refund;
import ac.za.cput.factory.admin.RefundFactory;
import ac.za.cput.repository.admin.RefundRepository;
import ac.za.cput.repository.admin.implementation.RefundRepositoryImpl;
import org.junit.Assert;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

import java.util.Set;
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RefundServiceImplTest {
    private RefundRepository repository;
    private Refund refund;

    private Refund getSavedRefund() {
        Set<Refund> savedRefunds = this.repository.getAll();
        return savedRefunds.iterator().next();
    }

    @Before
    public void setUp() throws Exception {

        this.repository = RefundRepositoryImpl.getRepository();
        this.refund = RefundFactory.getRefund("1234",100);
    }

    @Test
    public void a_create() {
        Refund created = this.repository.create(this.refund);
        System.out.println("In create, created = " + created);
        d_getAll();
        Assert.assertSame(created, this.refund);
    }


    @Test
    public void b_read() {
        Refund savedRefund = getSavedRefund();
        System.out.println("In read, RefundId = "+ savedRefund.id());
        Refund read = this.repository.read(savedRefund.id());
        System.out.println("In read, read = " + read);
        d_getAll();
        Assert.assertEquals(savedRefund, read);
    }

    @Test
    public void e_delete() {
        Refund savedRefund = getSavedRefund();
        this.repository.delete(savedRefund.id());
        //d_getAll();
        System.out.println( "Refund deleted" );
        Assert.assertEquals(0,repository.getAll().size());
    }

    @Test
    public void d_getAll() {
        Set<Refund> all = this.repository.getAll();
        System.out.println("In getAll, all = " + all);
        Assert.assertSame(1, all.size());
    }

    @Test
    public void c_update() {
        double  newnam = 12;
        Refund refund = new Refund.Builder().copy(getSavedRefund()).amount(newnam).build();
        System.out.println("In update, about_to_updated = " + refund);
        Refund updated = this.repository.update(refund);
        System.out.println("In update, updated = " + refund);
        Assert.assertSame(newnam, updated.amount());
        d_getAll();
    }
}
