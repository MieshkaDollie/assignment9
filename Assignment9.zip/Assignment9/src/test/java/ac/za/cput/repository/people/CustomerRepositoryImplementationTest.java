package ac.za.cput.repository.people;

import ac.za.cput.domain.people.Customer;
import ac.za.cput.factory.people.CustomerFactory;
import ac.za.cput.repository.people.CustomerRepository;
import ac.za.cput.repository.people.implementation.CustomerRepositoryImpl;
import org.junit.Assert;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

import java.util.Set;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class CustomerRepositoryImplementationTest {


    private CustomerRepository repository;
    private Customer customer ;

    private Customer getSavedCustomer() {
        Set<Customer> savedCustomers = this.repository.getAll();
        return savedCustomers.iterator().next();
    }

    @Before
    public void setUp() throws Exception {

        this.repository = CustomerRepositoryImpl.getRepository();
        this.customer = CustomerFactory.getCustomer("125","Paul","Marty",34,"PaulMarty@gmail.com","+2748656882");
    }

    @Test
    public void a_create() {
        Customer created = this.repository.create(this.customer);
        System.out.println("In create, created = " + created);
        d_getAll();
        Assert.assertSame(created, this.customer);
    }

    @Test
    public void b_read() {
        Customer savedCustomer = getSavedCustomer();
        System.out.println("In read, CustmoerId = "+ savedCustomer.getId());
        Customer read = this.repository.read(savedCustomer.getId());
        System.out.println("In read, read = " + read);
        d_getAll();
        Assert.assertEquals(savedCustomer, read);
    }

    @Test
    public void e_delete() {
        Customer savedCustomer = getSavedCustomer();
        this.repository.delete(savedCustomer.getId());
        //d_getAll();
        System.out.println( "Customer deleted" );
        Assert.assertEquals(0,repository.getAll().size());
    }

    @Test
    public void d_getAll() {
        Set<Customer> all = this.repository.getAll();
        System.out.println("In getAll, all = " + all);
        Assert.assertSame(1, all.size());
    }

    @Test
    public void c_update() {
        String newfname = "Alves";
        Customer customer = new Customer.Builder().copy(getSavedCustomer()).firstName(newfname).build();
        System.out.println("In update, about_to_updated = " + customer);
        Customer updated = this.repository.update(customer);
        System.out.println("In update, updated = " + updated);
        Assert.assertSame(newfname, updated.getFirstName());
        d_getAll();
    }

}
