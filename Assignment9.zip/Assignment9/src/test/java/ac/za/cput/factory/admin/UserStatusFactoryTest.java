package ac.za.cput.factory.admin;

public class UserStatusFactoryTest {
}
