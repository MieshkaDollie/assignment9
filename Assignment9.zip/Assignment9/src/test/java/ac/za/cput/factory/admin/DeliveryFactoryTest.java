package ac.za.cput.factory.admin;

import ac.za.cput.domain.admin.Delivery;
import ac.za.cput.factory.admin.DeliveryFactory;
import org.junit.Assert;
import org.junit.Test;

public class DeliveryFactoryTest {

    @Test
    public void getDelivery(){

        String code="hdb6d";
        String date="10/03/2018";

        Delivery d= DeliveryFactory.getDelivery(code,date);
        System.out.println( d);
        Assert.assertEquals("10/03/2018",d.getDate());
    }
}
