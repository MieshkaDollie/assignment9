package ac.za.cput.factory.admin;

import ac.za.cput.domain.admin.OrderStatus;
import ac.za.cput.factory.admin.OrderStatusFactory;
import org.junit.Assert;
import org.junit.Test;

public class OrderStatusFactoryTest {
    @Test
    public void getOrderLine() {

        String custid="12rer4";
        String ordernum="1234";



        OrderStatus orderStatus = OrderStatusFactory.getOrderStatus(ordernum,custid);
        System.out.println(orderStatus);
        Assert.assertEquals("1234", orderStatus.getOrderNumber());
    }
}
