package ac.za.cput.repository.admin;

import ac.za.cput.domain.admin.Book;
import ac.za.cput.factory.admin.BookFactory;
import ac.za.cput.repository.admin.BookRepository;

import ac.za.cput.repository.admin.implementation.BookRepositoryImplementation;
import org.junit.Assert;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

import java.util.Set;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class BookRepositoryImplTest {

    private BookRepository repository;
    private Book book;

    private Book getSavedBook() {
        Set<Book> savedBooks = this.repository.getAll();
        return savedBooks.iterator().next();
    }

    @Before
    public void setUp() throws Exception {

        this.repository = BookRepositoryImplementation.getRepository();
        this.book = BookFactory.getBook("1234","12 Rules for life","Jordan peterson","Psychology","1st","10/3/2019","SKFJHV");
    }

    @Test
    public void a_create() {
        Book created = this.repository.create(this.book);
        System.out.println("In create, created = " + created);
        d_getAll();
        Assert.assertSame(created, this.book);
    }

    @Test
    public void b_read() {
        Book savedBook = getSavedBook();
        System.out.println("In read, BookId = "+ savedBook.getBookId());
        Book read = this.repository.read(savedBook.getBookId());
        System.out.println("In read, read = " + read);
        d_getAll();
        Assert.assertEquals(savedBook, read);
    }

    @Test
    public void e_delete() {
        Book savedBook = getSavedBook();
        this.repository.delete(savedBook.getBookId());
        //d_getAll();
        System.out.println( "Book deleted" );
        Assert.assertEquals(0,repository.getAll().size());
    }

    @Test
    public void d_getAll() {
        Set<Book> all = this.repository.getAll();
        System.out.println("In getAll, all = " + all);
       Assert.assertSame(1, all.size());
    }

   @Test
    public void c_update() {
        String newname = "7 rules";
        Book book = new Book.Builder().copy(getSavedBook()).title(newname).build();
        System.out.println("In update, about_to_updated = " + book);
        Book updated = this.repository.update(book);
        System.out.println("In update, updated = " + updated);
        Assert.assertSame(newname, updated.getTitle());
        d_getAll();
    }
}