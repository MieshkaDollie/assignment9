package ac.za.cput.repository.admin;

import ac.za.cput.domain.admin.Review;
import ac.za.cput.factory.admin.ReviewFactory;
import ac.za.cput.repository.admin.ReviewRepository;
import ac.za.cput.repository.admin.implementation.ReviewRepositoryImpl;
import org.junit.Assert;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

import java.util.Set;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class ReviewRepositoryImplementationTest {

    private ReviewRepository repository;
    private Review review ;

    private Review getSavedReview() {
        Set<Review> savedReviews = this.repository.getAll();
        return savedReviews.iterator().next();
    }

    @Before
    public void setUp() throws Exception {

        this.repository = ReviewRepositoryImpl.getRepository();
        this.review= ReviewFactory.getReview("1234","17766","Jordan peterson");
    }

    @Test
    public void a_create() {
        Review created = this.repository.create(this.review);
        System.out.println("In create, created = " + created);
        d_getAll();
        Assert.assertSame(created, this.review);
    }

    @Test
    public void b_read() {
        Review savedReview = getSavedReview();
        System.out.println("In read, ReviewId = "+ savedReview.getReviewId());
        Review read = this.repository.read(savedReview.getReviewId());
        System.out.println("In read, read = " + read);
        d_getAll();
        Assert.assertEquals(savedReview, read);
    }

    @Test
    public void e_delete() {
        Review savedReview = getSavedReview();
        this.repository.delete(savedReview.getReviewId());
        //d_getAll();
        System.out.println( "Review deleted" );
        Assert.assertEquals(0,repository.getAll().size());
    }

    @Test
    public void d_getAll() {
        Set<Review> all = this.repository.getAll();
        System.out.println("In getAll, all = " + all);
        Assert.assertSame(1, all.size());
    }

    @Test
    public void c_update() {
        String newc = "11111";
        Review review = new Review.Builder().copy(getSavedReview()).customerId(newc).build();
        System.out.println("In update, about_to_updated = " + review);
        Review updated = this.repository.update(review);
        System.out.println("In update, updated = " + review);
        Assert.assertSame(newc, updated.getCustomerId());
        d_getAll();
    }

}
