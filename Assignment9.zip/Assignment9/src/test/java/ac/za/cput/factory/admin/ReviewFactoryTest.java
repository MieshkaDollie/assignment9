package ac.za.cput.factory.admin;

import ac.za.cput.domain.admin.Review;
import ac.za.cput.factory.admin.ReviewFactory;
import org.junit.Assert;
import org.junit.Test;

public class ReviewFactoryTest {



    @Test
    public void getReview() {

        String reviewid="de333";
        String custid = "C2833";
        String cont = "Stones czv ...";


        Review review = ReviewFactory.getReview(reviewid,custid,cont);
        System.out.println(review);
        Assert.assertEquals("de333", review.getReviewId());
    }
}
