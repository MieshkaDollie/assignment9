package ac.za.cput.service.admin;

import ac.za.cput.domain.admin.Cart;
import ac.za.cput.factory.admin.CartFactory;
import ac.za.cput.repository.admin.CartRepository;
import ac.za.cput.repository.admin.implementation.CartRepositoryImpl;
import org.junit.Assert;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

import java.util.Set;
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class CartServiceImplTest {
    private CartRepository repository;
    private Cart cart;

    private Cart getSavedCart() {
        Set<Cart> savedCarts = this.repository.getAll();
        return savedCarts.iterator().next();
    }

    @Before
    public void setUp() throws Exception {

        this.repository = CartRepositoryImpl.getRepository();
        this.cart = CartFactory.getCart("1232d4","frgjt7t",200,"dgk;k");
    }

    @Test
    public void a_create() {
        Cart created = this.repository.create(this.cart);
        System.out.println("In create, created = " + created);
        d_getAll();
        Assert.assertNotNull(created);
        Assert.assertSame(created, this.cart);
    }

    @Test
    public void b_read() {
        Cart savedCart = getSavedCart();
        System.out.println("In read, CartId = "+ savedCart.getId());
        Cart read = this.repository.read(savedCart.getId());
        System.out.println("In read, read = " + read);
        d_getAll();
        Assert.assertEquals(savedCart, read);
    }

    @Test
    public void e_delete() {
        Cart savedCart = getSavedCart();
        this.repository.delete(savedCart.getId());
        //d_getAll();
        System.out.println( "Cart deleted" );
        Assert.assertEquals(0,repository.getAll().size());
    }

    @Test
    public void d_getAll() {
        Set<Cart> all = this.repository.getAll();
        System.out.println("In getAll, all = " + all);
        Assert.assertSame(1, all.size());
    }

    @Test
    public void c_update() {
        int newamount = 100;
        Cart cart = new Cart.Builder().copy(getSavedCart()).amount(newamount).build();
        System.out.println("In update, about_to_updated = " + cart);
        Cart updated = this.repository.update(cart);
        System.out.println("In update, updated = " + cart);
        Assert.assertSame(newamount, updated.getAmount());
        d_getAll();
    }

}
