package ac.za.cput.service.admin;

import ac.za.cput.domain.admin.Address;
import ac.za.cput.factory.admin.AddressFactory;
import ac.za.cput.repository.admin.AddressRepository;
import ac.za.cput.repository.admin.implementation.AddressRepositoryImpl;
import org.junit.Assert;
import org.junit.Before;


import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.List;

@SpringBootTest
@RunWith(SpringRunner.class)
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class AddressServiceImplTest {
    @Autowired
    private AddressRepository repository;
    private Address address;

    private Address getSavedAddress() {
        List<Address> savedAddresses = this.repository.getAll();
        return savedAddresses.iterator().next();
    }

    @Before
    public void setUp() throws Exception {

        this.repository = AddressRepositoryImpl.getRepository();
        this.address = AddressFactory.getAddress("5 PARMA","SIGNAL","SOUTH","PARIS","FRANCE");

    }

    @Test
    public void a_create() {
        Address created = this.repository.create(this.address);
        System.out.println("In create, created = " + created);
        d_getAll();
        Assert.assertNotNull(created);
        Assert.assertSame(created, this.address);
    }

    @Test
    public void b_read() {
        Address savedAddress = getSavedAddress();
        System.out.println("In read, Type = "+ savedAddress.getType());
        Address read = this.repository.read(savedAddress.getType());
        System.out.println("In read, read = " + read);
        d_getAll();
        Assert.assertEquals(savedAddress, read);
    }

    @Test
    public void e_delete() {
        Address savedAddress = getSavedAddress();
        this.repository.delete(savedAddress.getType());
        // d_getAll();
        System.out.println( "Address deleted" );
        Assert.assertEquals(0,repository.getAll().size());
    }

    @Test
    public void d_getAll() {
        List<Address> all = this.repository.getAll();
        System.out.println("In getAll, all = " + all);
        Assert.assertSame(1, all.size());
    }

    @Test
    public void c_update() {
        String newStreet = "COSTA";
        Address address = new Address.Builder().copy(getSavedAddress()).street(newStreet).build();
        System.out.println("In update, about_to_updated = " + address);
        Address updated = this.repository.update(address);
        System.out.println("In update, updated = " + address);
        Assert.assertSame(newStreet, updated.getStreet());
        d_getAll();
    }
}
