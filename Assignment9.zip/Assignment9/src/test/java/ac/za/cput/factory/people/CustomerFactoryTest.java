package ac.za.cput.factory.people;

import ac.za.cput.domain.people.Customer;
import ac.za.cput.factory.people.CustomerFactory;
import org.junit.Assert;
import org.junit.Test;

public class CustomerFactoryTest {


    @Test
    public void getCustomer() {

        String id="C2833";
        String fname = "John";
        String lname = "Stones";
        String email="johnstones@gmail.com";
        String phone="+2784759892";
        int age=29;

        Customer customer = CustomerFactory.getCustomer(id,fname,lname,age,email,phone);
        System.out.println(customer);
        Assert.assertEquals(29, customer.getAge());
    }
}
