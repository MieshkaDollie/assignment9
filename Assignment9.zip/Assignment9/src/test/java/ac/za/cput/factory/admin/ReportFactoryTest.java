package ac.za.cput.factory.admin;

import ac.za.cput.domain.admin.Report;
import ac.za.cput.factory.admin.ReportFactory;
import org.junit.Assert;
import org.junit.Test;

public class ReportFactoryTest {

    @Test
    public void getReport() {

        String date="1/1/2019";
        String description = "12 rules for life";
        int sale=4000;



        Report report =  ReportFactory.getReport("121455tg",date,description,sale);
        System.out.println(report);
        Assert.assertEquals("1/1/2019", report.getDate());
    }
}
