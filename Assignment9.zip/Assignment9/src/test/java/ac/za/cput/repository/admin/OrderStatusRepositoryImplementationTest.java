package ac.za.cput.repository.admin;

import ac.za.cput.domain.admin.Invoice;
import ac.za.cput.domain.admin.Order;
import ac.za.cput.factory.admin.InvoiceFactory;
import ac.za.cput.factory.admin.OrderFactory;
import ac.za.cput.repository.admin.InvoiceRepository;
import ac.za.cput.repository.admin.OrderRepository;
import ac.za.cput.repository.admin.implementation.InvoiceRepositoryImpl;
import ac.za.cput.repository.admin.implementation.OrderRepositoryImpl;
import org.junit.Assert;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

import java.util.Set;
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class OrderStatusRepositoryImplementationTest {
    private OrderRepository repository;
    private Order order;

    private Order getSavedOrder() {
        Set<Order> savedOrders = this.repository.getAll();
        return savedOrders.iterator().next();
    }

    @Before
    public void setUp() throws Exception {

        this.repository = OrderRepositoryImpl.getRepository();
        this.order = OrderFactory.getOrder("124534","2325rgd",100,"1st,");
    }

    @Test
    public void a_create() {
        Order created = this.repository.create(this.order);
        System.out.println("In create, created = " + created);
        d_getAll();
        Assert.assertSame(created, this.order);
    }

    @Test
    public void b_read() {
        Order savedOrder = getSavedOrder();
        System.out.println("In read, BookId = "+ savedOrder.getOrderNumber());
        Order read = this.repository.read(savedOrder.getOrderNumber());
        System.out.println("In read, read = " + read);
        d_getAll();
        Assert.assertEquals(savedOrder, read);
    }

    @Test
    public void e_delete() {
        Order savedOrder = getSavedOrder();
        this.repository.delete(savedOrder.getOrderNumber());
        //d_getAll();
        System.out.println( "Order deleted" );
        Assert.assertEquals(0,repository.getAll().size());
    }

    @Test
    public void d_getAll() {
        Set<Order> all = this.repository.getAll();
        System.out.println("In getAll, all = " + all);
        Assert.assertSame(1, all.size());
    }

    @Test
    public void c_update() {
        String newdesc = "Descripiton";
        Order order = new Order.Builder().copy(getSavedOrder()).description(newdesc).build();
        System.out.println("In update, about_to_updated = " + order);
        Order updated = this.repository.update(order);
        System.out.println("In update, updated = " + order);
        Assert.assertSame(newdesc, updated.getDescription());
        d_getAll();
    }
}
