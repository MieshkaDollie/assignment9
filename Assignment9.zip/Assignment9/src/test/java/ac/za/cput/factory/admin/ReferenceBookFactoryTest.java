package ac.za.cput.factory.admin;

import ac.za.cput.domain.admin.ReferenceBook;
import ac.za.cput.factory.admin.ReferenceBookFactory;
import org.junit.Assert;
import org.junit.Test;

public class ReferenceBookFactoryTest {

    @Test
    public void getGeneralBook(){

        String id="hdb6d";
        String title="circle";

        ReferenceBook rb= ReferenceBookFactory.getReferenceBook(id,title);
        System.out.println( rb);
        Assert.assertEquals("circle",rb.getTitle());
    }
}
