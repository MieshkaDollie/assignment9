package ac.za.cput.repository.admin;

import ac.za.cput.domain.admin.Payment;
import ac.za.cput.factory.admin.PaymentFactory;
import ac.za.cput.repository.admin.PaymentRepository;
import ac.za.cput.repository.admin.implementation.PaymentRepositoryImpl;
import org.junit.Assert;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

import java.util.Set;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class PaymentRepositoryImplementationTest {

    private PaymentRepository repository;
    private Payment payment;

    private Payment getSavedPayment() {
        Set<Payment> savedPayments = this.repository.getAll();
        return savedPayments.iterator().next();
    }

    @Before
    public void setUp() throws Exception {

        this.repository = PaymentRepositoryImpl.getRepository();
        this.payment = PaymentFactory.getPayment("124534",100);
    }

    @Test
    public void a_create() {
        Payment created = this.repository.create(this.payment);
        System.out.println("In create, created = " + created);
        d_getAll();
        Assert.assertSame(created, this.payment);
    }

    @Test
    public void b_read() {
        Payment savedPayment = getSavedPayment();
        System.out.println("In read, PaymentId = "+ savedPayment.getId());
        Payment read = this.repository.read(savedPayment.getId());
        System.out.println("In read, read = " + read);
        d_getAll();
        Assert.assertEquals(savedPayment, read);
    }


    @Test
    public void e_delete() {
        Payment savedPayment = getSavedPayment();
        this.repository.delete(savedPayment.getId());
        //d_getAll();
        System.out.println( "Payment deleted" );
        Assert.assertEquals(0,repository.getAll().size());
    }

    @Test
    public void d_getAll() {
        Set<Payment> all = this.repository.getAll();
        System.out.println("In getAll, all = " + all);
        Assert.assertSame(1, all.size());
    }

    @Test
    public void c_update() {
        double newam = 10;
        Payment payment = new Payment.Builder().copy(getSavedPayment()).amount(newam).build();
        System.out.println("In update, about_to_updated = " + payment);
        Payment updated = this.repository.update(payment);
        System.out.println("In update, updated = " + payment);
        Assert.assertSame(newam, updated.getAmount());
        d_getAll();
    }
}
